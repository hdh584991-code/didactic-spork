# 守烬人 Emberkeeper —— 杀戮尖塔2 新角色 Mod

面向 **《杀戮尖塔 2》v0.111.0 (41cef1ea)** 的可玩角色 Mod，基于 **BaseLib**。

> 这一版严格只做「加人物」：一个完整的新角色 + 让它能进场打牌的最小起始包。
> 没有额外卡牌库、没有新怪物、没有新事件。

---

## 一、角色设定

**守烬人（Emberkeeper）** — 塔火熄灭后仍未离开的人，把没烧完的余烬收进胸腔。

| 项目 | 数值 |
| --- | --- |
| 初始血量 | 75 |
| 初始金币 | 99 |
| 性别（影响动态文本） | 中立 |
| 主题色 | 暗橙 `#D8591F` |

**核心机制：余烬（Ember）**

- 自己的**回合开始时**，身上所有余烬燃尽，等量转化为格挡。
- **薪击**（起始攻击牌）：造成 6（升级 9）点伤害，获得 1 层余烬。
- **守烬**（起始防御牌）：获得 5（升级 8）点格挡，获得 2 层余烬。
- **燃烬**（专属起始牌）：获得 3（升级 4）点格挡，造成 8（升级 11）点伤害，获得 1（升级 2）层余烬。
- **余烬心核**（起始遗物）：每回合开始时获得 1 层余烬。

于是形成节奏：**这回合打得越凶 → 攒的余烬越多 → 下回合开局越耐打**。
这就是「守烬」两个字的字面意思：把火守到它变成护甲。

**起始卡组（11 张）** = 5×薪击 + 5×守烬 + 1×燃烬，起始遗物 = 余烬心核×1。

---

## 二、环境要求

| 依赖 | 版本 |
| --- | --- |
| 杀戮尖塔 2 | **v0.111.0**（其它版本需重新核对 API） |
| .NET SDK | 9.0 |
| Godot（.NET 版） | 4.5.1（MegaDot / 官方 4.5.1 均可，**不要更高版本**，否则 pck 会被游戏拒绝） |
| BaseLib | 前置库，见下 |

### 安装 BaseLib 前置

**方式一：一键脚本（推荐）**

- Windows：右键 `tools/install_baselib.ps1` → 使用 PowerShell 运行
  （若提示禁止运行脚本，管理员 PowerShell 先跑一次 `Set-ExecutionPolicy -Scope Process RemoteSigned`）
- macOS / Linux：`bash tools/install_baselib.sh`

脚本会自动从 GitHub 拉最新版、解压到 `mods/BaseLib/`、并校验三件套是否齐全。

**方式二：手动**

1. 打开 <https://github.com/Alchyr/BaseLib-StS2/releases>，下载最新版本的 zip。
2. 把里面的 `BaseLib.dll`、`BaseLib.pck`、`BaseLib.json` 三个文件放进
   `Slay the Spire 2/mods/BaseLib/`（macOS 是 `SlayTheSpire2.app/Contents/MacOS/mods/BaseLib/`）。
3. 进游戏在 Mods 菜单里启用一次。

> ⚠️ **版本必须匹配**：BaseLib 跟游戏版本强耦合，旧版 BaseLib 在新游戏上会直接崩或出牌失效。
> 你是 v0.111.0，请装 **v3.4.4 或更高**（不要用 Nexus 上停更的 3.3.8）。
> 若游戏日后更新，重跑一次脚本拿最新版即可。

> ℹ️ Steam 创意工坊也有 BaseLib，但有反馈说工坊版在部分机器上不稳定，
> 出问题就改回 GitHub 手动下载的版本。

---

## 三、目录结构

```
Emberkeeper/
├── Emberkeeper.csproj          # 项目文件（改 Sts2Dir 为你的游戏目录）
├── Emberkeeper.json            # mod 清单（id / 依赖 / 版本）
├── project.godot               # Godot 项目（用来打 pck）
├── local.props.template        # 复制成 local.props 填游戏路径
├── Code/                       # C# 源码 → 编译成 Emberkeeper.dll
│   ├── Entry.cs                # [ModInitializer] 入口
│   ├── Characters/
│   │   ├── EmberkeeperCharacter.cs   # ★ 角色本体
│   │   └── Pools/EmberPools.cs      # 卡池 / 遗物池 / 药水池
│   ├── Cards/
│   │   ├── EmberCardModel.cs   # 卡牌基类（统一卡图路径）
│   │   ├── EmberStrike.cs      # 起始打击
│   │   └── EmberDefend.cs      # 起始防御
│   ├── Powers/EmberPower.cs    # 核心状态「余烬」
│   └── Relics/EmberHeart.cs    # 起始遗物
└── Emberkeeper/                # 资源目录，名字必须 = modId
    ├── mod_image.png
    ├── localization/{zhs,eng}/
    │   ├── characters.json  cards.json  relics.json  powers.json  ancients.json
    ├── scenes/*.tscn        # 角色 / 能量表盘 / 选人背景 / 商店 / 篝火
    └── images/              # 占位美术（见第五节）
```

**资源文件夹名必须和 `Emberkeeper.json` 的 `id` 完全一致**，否则本地化和场景都找不到。

---

## 四、构建与安装

### 1. 编译 DLL

```bash
cp local.props.template local.props   # 编辑里面的 Sts2Dir
dotnet build
```

构建成功后会自动把 `Emberkeeper.dll` + `Emberkeeper.json` 拷到
`Slay the Spire 2/mods/Emberkeeper/`。

### 2. 导出 PCK

用 Godot 4.5.1 打开本目录的 `project.godot`：

- 先到 **项目 → 项目设置** 里确认「将文本资源转换为二进制」是**关闭**的。
- 打开项目时 Godot 可能会抱怨 `Code/` 里的 C# 编译不过（它们本来就是靠外部 `dotnet build` 编的，不引用游戏 dll 当然编不过）——**直接忽略即可**，不影响导出 pck。
- **项目 → 导出 → 添加 → Windows Desktop**。
- Resources 选 **Export selected resources (and dependencies)**，勾上 `Emberkeeper/`（资源目录）和 `Emberkeeper/mod_image.png`；Exclude Filter 填 `Code/*` 把源码排除掉。
- **Export PCK/ZIP…** 存成 `Emberkeeper.pck`。

命令行等价写法：

```bash
godot --headless --export-pack "Windows Desktop" Emberkeeper.pck
```

### 3. 安装

把三件套放进同一目录：

```
Slay the Spire 2/mods/Emberkeeper/
├── Emberkeeper.dll
├── Emberkeeper.json
└── Emberkeeper.pck
```

启动器选 **Play with Mods** → Mods 菜单勾选「守烬人 Emberkeeper」→ 重启 → 选人界面即可看到守烬人。

### 4. 调试

进游戏按 `~` 开控制台：

```
card EMBERKEEPER-EMBER_STRIKE     # 给自己一张薪击（需在战斗中）
relic add EMBERKEEPER-EMBER_HEART
power EMBERKEEPER-EMBER_POWER 5 0
```

Mod 的日志在控制台输入 `open logs` 打开目录查看。

---

## 五、占位美术：这些图要换成你自己的

现在包里全是程序生成的占位图（纯色 + 文字），能跑通但很丑。换成正式美术时**保持文件名和尺寸**即可，不用改代码：

| 文件 | 尺寸 | 用途 |
| --- | --- | --- |
| `images/energy_ember.png` | 24×24 | 描述文字里的能量图标 |
| `images/energy_ember_big.png` | 74×74 | 卡面左上角能量图标 |
| `images/char_select_emberkeeper.png` | 建议 640×480 | 选人界面立绘 |
| `images/char_select_emberkeeper_locked.png` | 同上 | 未解锁状态 |
| `images/character_placeholder.png` | 256×256 | 战斗 / 商店 / 篝火立绘占位 |
| `images/cards/EmberStrike.png` | 250×190 | 卡图 |
| `images/cards/EmberDefend.png` | 250×190 | 卡图 |
| `images/relics/emberheart.png` | 256×256（小图会自动缩放） | 遗物图标 |
| `images/relics/emberheart_outline.png` | 256×256 | 遗物描边图 |
| `images/powers/ember.png` | 256×256 | 状态图标 |

### 当前美术方案：全套借用静默猎手

角色继承 `PlaceholderCharacterModel`，`PlaceholderID = "silent"`，
立绘 / 音效 / 动画 / 能量盘 / 选人背景**全部借用静默猎手的资源**。

`EmberkeeperCharacter.cs` 顶部有一个总开关：

```csharp
public const bool UseCustomArt = false;   // 改成 true 就切到你自己的贴图
```

- `false`（现在）：所有美术属性回退到 `base.XXX`，也就是 silent 的原版资源
- `true`（以后）：自动指向 `Emberkeeper/images`、`Emberkeeper/scenes` 下你自己的文件

**只改这一个 bool，不用动别的地方**，也不用碰 `#if` 或 csproj。

想换别的角色当底子，改 `PlaceholderID` 即可：`ironclad` / `silent` / `defect` / `regent` / `necrobinder`。

### 文本显示：代码内联本地化（不依赖 json）

之前选人界面显示成别的角色的名字和介绍，是因为 pck 里的 json 没有被正确读到。

现在改用 BaseLib 提供的内联接口，**直接在 C# 里写文本**：

```csharp
public override List<(string, string)>? Localization =>
[
    ("title", "守烬人"),
    ("description", "..."),
];
```

角色、三张卡、遗物、余烬状态**全都有内联本地化**，
不依赖任何外部 json 文件和 key 拼接规则，所以名字一定显示正确。

pck 里的 `localization/` json 依然保留作为兜底，两者不冲突。

想做动画时，把 `scenes/emberkeeper_character.tscn` 里的 `Visuals` 节点换成
`SpineSprite` / `AnimatedSprite2D` / `AnimationPlayer`，并保证动画名是
`idle_loop`、`attack`、`cast`、`hurt`、`die` 这五个。

---

## 六、可能需要你本地核对的 3 个 API

Mod 没有官方 API，游戏每次更新都可能改签名。下面几处是按 v0.111.0 时期的 BaseLib 惯例写的，
**如果编译报错，用 ILSpy 反编译 `sts2.dll` 搜一下同名方法即可**（方法体不用动）：

```bash
dotnet tool install -g ilspycmd
ilspycmd -p -o ./decompiled "…/Slay the Spire 2/data_sts2_windows_x86_64/sts2.dll"
```

1. **`EmberPower.AfterTurnStart(PlayerChoiceContext, Creature)`**
   回合开始钩子名可能是 `BeforeTurnStart` / `AfterPlayerTurnStart`，参数类型也可能不同。
2. **`PowerCmd.Remove(this)`**
   移除自身层数。若无此方法，改成注释里备用的
   `await PowerCmd.Apply(choiceContext, Owner, -amount, Owner, null);`
3. **`PowerCmd.Apply<T>(choiceContext, creature, amount, applier, cardPlay)`**
   给角色上状态的泛型入口，参数顺序按你本地签名调整。

另外 `ScriptManagerBridge.LookupScriptsInAssembly(...)` 的命名空间，
若在 `MegaCrit.Sts2.Core.Scripting` 下报错，让 IDE 自动导入正确的命名空间即可。

---

## 七、接下来往哪儿加东西

- **加一张卡**：`Code/Cards/` 新建类继承 `EmberCardModel`，打上
  `[Pool(typeof(EmberCardPool))]`，再往 `localization/zhs/cards.json` 补
  `EMBERKEEPER-{类名大写snake}.title / .description`。
  ID 规则：命名空间第一段大写 + `-` + 类名的大写 snake_case。
- **加遗物**：继承 `CustomRelicModel` + `[Pool(typeof(EmberRelicPool))]`。
- **改数值**：血量在 `EmberkeeperCharacter.StartingHp`，起始卡组在 `StartingDeck`。
- **加专属机制牌**：余烬层数只是个普通 `CustomPowerModel`，你可以随意在任意卡牌里
  `PowerCmd.Apply<EmberPower>(...)` 增减它。

---

## 八、卸载

关掉游戏，删掉 `Slay the Spire 2/mods/Emberkeeper/` 整个文件夹即可。
Mod 档和原版档是分开的，删之前记得备份存档（在 `AppData/LocalLow/Mega Crit`）。
