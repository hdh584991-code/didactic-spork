# 守烬人（Emberkeeper）

给《杀戮尖塔 2》 v0.111.0 添加一个新可玩角色。

严格按官方教程实现（BaseLib 篇第 14 章「添加新人物」，以及第 01/03/05 章的卡牌、遗物、能力）。

## 角色设定

**守烬人**，75 血 / 99 金。

**核心机制「余烬（Ember）」**：回合开始时，身上的余烬全部燃尽，等量转化为格挡。
所以这回合打得越凶，下回合开局越耐打——把火守到它变成护甲。

| 内容 | 名称 | 效果 |
|---|---|---|
| 基础攻击 ×5 | 薪击 | 6 伤害 + 1 余烬（升级 9 伤害） |
| 基础防御 ×5 | 守烬 | 5 格挡 + 2 余烬（升级 8 格挡） |
| 专属起始牌 ×1 | 燃烬 | 8 伤害 + 3 格挡 + 1 余烬（升级 11 / 4 / 2） |
| 起始遗物 | 余烬心核 | 每回合开始 +1 余烬 |

## 目录结构

按官方模板「05-模板/原生模组模板」组织：

```
Emberkeeper/                       Godot 工程根（res:// 的根）
├── Emberkeeper.csproj
├── Emberkeeper.json               清单（id 必须和资源文件夹名一致）
├── Emberkeeper-NoPck.json         pck 导出失败时用的回退清单
├── project.godot
├── export_presets.cfg
├── PROJECT.md                     项目档案
├── Scripts/                       C# 源码（有 .gdignore，Godot 不扫描）
│   ├── .gdignore
│   ├── Entry.cs                   入口（[ModInitializer]）
│   ├── Cards/                     EmberCardModel + 三张卡
│   ├── Relics/EmberHeart.cs
│   ├── Powers/EmberPower.cs
│   └── Characters/
│       ├── EmberkeeperCharacter.cs
│       └── Pools/EmberPools.cs    卡池 / 遗物池 / 药水池
├── Emberkeeper/                   资源目录（名字 = 清单 id）
│   ├── images/                    12 张贴图
│   └── localization/{zhs,eng}/    中英双语
└── tools/                         构建脚本（有 .gdignore）
```

## ID 规则

命名空间第一段大写作为前缀，所以所有模型 ID 都是 `EMBERKEEPER-` 开头：

- 角色：`EMBERKEEPER-EMBERKEEPER_CHARACTER`
- 卡牌：`EMBERKEEPER-EMBER_STRIKE` / `EMBER_DEFEND` / `EMBER_BURST`
- 遗物：`EMBERKEEPER-EMBER_HEART`
- 状态：`EMBERKEEPER-EMBER_POWER`

游戏内按 `~` 打开控制台，执行 `dump` 可以核对实际注册结果。

## 美术方案

场景类资源（战斗模型、能量盘、选人背景、商店/篝火）**全部沿用静默猎手**（`PlaceholderID = "silent"`）。
教程明确建议：没有的资源直接注释掉以使用原版。

只有纯图片的选人立绘 / 未解锁立绘 / 左上角头像用自己的图，由角色类里的
`UseCustomImages` 控制。

⚠️ 只有当 pck 真的打进包时 `true` 才有意义。构建脚本会在 pck 导出失败时
自动改成 `false` 并换用 `has_pck: false` 的清单，保证产物一定自洽。

## 构建

### 方式一：GitHub Actions（无需本地环境）

1. 把本目录打包成 `Emberkeeper.zip`（zip 内顶层是 `Emberkeeper/` 文件夹）
2. 传到 GitHub 仓库
3. 创建 `.github/workflows/build.yml`，内容见同目录同名文件
4. Actions 跑完，下载 `Emberkeeper-mod`

工作流会自动：编译 dll → 下载 Godot 4.5.1 导出 pck → 打包 BaseLib → 一致性校验。

### 方式二：本地一键构建

需要 .NET 9 SDK（Godot 可选，没有就出精简版）：

```bash
bash tools/build-local.sh
```

## 安装

下载产物 `Emberkeeper-mod.zip`，解压得到：

```
mods/
├── BaseLib/       前置库（dll + json + pck）
└── Emberkeeper/   本体（dll + json + pck）
```

把这两个文件夹**一起**丢进游戏 `mods/` 目录，启动器选 Play with Mods 并勾选。

## 已知限制

- **余烬 → 格挡的回合钩子尚未接上**。BaseLib 各版本的钩子名和签名不一致，
  凭猜测写会编译失败。工作流的「探测 API 签名」步骤会打印真实签名，
  拿到后即可补上。在此之前余烬能正常叠层和显示，只是不会自动转成格挡。
- 自定义战斗场景 / Spine 动画尚未制作。
- `eng/ancients.json` 目前是中文内容的副本，英文文案待补。
