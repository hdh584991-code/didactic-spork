# 模组项目档案

模组名称：守烬人（Emberkeeper）
作者：（待填）
模组 ID：Emberkeeper
目标游戏版本：0.111.0 (41cef1ea)
模组 API 或框架版本：BaseLib 3.4.7（NuGet 包声明 3.*）
项目类型：新可玩角色
当前阶段：开发中

## 项目目标

玩家最终会看到什么：选人界面多出一个名为「守烬人」的角色，75 血、99 金，
起始卡组 5 张薪击 + 5 张守烬 + 1 张燃烬，起始遗物余烬心核。
战斗中使用卡牌会积攒「余烬」，回合开始时余烬燃尽并等量转化为格挡。

## 已完成

- 角色类、三张卡、起始遗物、余烬状态、三个内容池（按教程 14 / 01 / 03 / 05 实现）
- 中英双语本地化（cards / characters / relics / powers / ancients）
- 12 张贴图（选人立绘、未解锁立绘、战斗立绘、三张卡图、能量图标×2、遗物图+描边、状态图标、Mod 图标）
- 云端构建流程（GitHub Actions）：编译 → 导出 pck → 打包 BaseLib → 一致性校验
- 目录结构对齐官方模板（`Scripts/` + `{modId}/` 资源目录 + `.gdignore`）

## 正在处理

- **余烬 → 格挡的回合钩子未接上**。BaseLib 各版本钩子名/签名不一致，
  已在工作流里加反射探测步骤，拿到真实签名后再补 `EmberPower` 的转化逻辑。
- 选人界面能否正常显示守烬人，待用户实机确认。

## 已知问题

- pck 若导出失败，构建会自动回退（UseCustomImages 改 false + has_pck=false），
  此时角色沿用 silent 原版美术，功能正常但没有自定义贴图。
- 场景类资源（战斗模型、能量盘、选人背景、商店/篝火）全部沿用 silent，
  没有做自定义场景。按教程，自定义场景需要根节点能被转换成 NCreatureVisuals。

## 项目专用约定

- 命名空间 `Emberkeeper.Scripts.*`，因此所有模型 ID 前缀是 `EMBERKEEPER-`
- 角色 ID：`EMBERKEEPER-EMBERKEEPER_CHARACTER`
- 卡图：`res://Emberkeeper/images/cards/{类名}.png`（由 EmberCardModel 统一指定）
- 遗物图：`res://Emberkeeper/images/relics/{Id.Entry 小写}.png`
- 状态图：`res://Emberkeeper/images/powers/ember_power.png`
- 美术开关：角色类里的 `UseCustomImages`

## 常见指代

- 项目简称：守烬人、Emberkeeper
- 角色或模组口语：「那个新人物」「余烬人」
- 可复用实现关键词：PlaceholderCharacterModel、CustomCardModel、[Pool]、CustomPowerModel

## 证据入口

- 源码：`Scripts/`
- 当前状态：PROJECT.md 本节
- 原作者或移植参考：01-官方与社区教程/SlayTheSpire2ModdingTutorials/BaseLib/14 - 添加新人物
- 运行日志与测试：GitHub Actions 的「探测 API 签名」步骤输出

## 工具与数据位置

- 项目专用工具：`tools/build-local.sh`（本地一键构建）、`tools/probe/`（API 反射探测）
- 本地化：`Emberkeeper/localization/{zhs,eng}/`
- 美术与音频源文件：`Emberkeeper/images/`
- 构建与部署入口：`.github/workflows/build.yml`


## 与官方模板的偏离（必须逐条记录，按 AGENTS.md 第 6 节）

本工程基底是 `05-模板/原生模组模板`，由 `04-工具/工作流/new-mod.ps1` 的结构生成。
以下 4 处是有意偏离，都有原因，不是随手改的：

1. **依赖 BaseLib**。官方模板是零第三方依赖的原生模组；
   但官方教程「14 - 添加新人物」明确要求依赖 BaseLib，
   自定义角色 / 卡牌 / 遗物 / Power 都继承它的 `Custom*Model`。
   因此 csproj 多了 BaseLib 引用，manifest 多了 `dependencies`。

2. **`include_filter` 从 `Emberkeeper/localization/*` 扩成 `Emberkeeper/*`**。
   官方注释写"只打包本地化"是因为模板里只有本地化资源；
   本模组还有 `images/`，不打进去贴图就全部失效。

3. **导出预设名保持官方默认的 `Windows Desktop`**。
   `pack-pck.ps1` 的 `-Preset` 默认值就是这个，
   必须与 `export_presets.cfg` 里的 `name` 一致，否则导出失败。

4. **新增 `Emberkeeper-NoPck.json`**。
   PCK 导出失败时的兜底清单（`has_pck: false`），
   保证产物永远自洽，不会出现"清单说有 pck 但实际没有"。

## 待用户裁决的一个问题

`export_presets.cfg` 里官方模板写的是 `texture_format/etc2_astc=false`
（只勾 `s3tc_bptc=true`）。但实测用户的游戏日志显示运行在 **Android**
（`com.megacrit.sts2beta`），而 Android 通常需要 ETC2/ASTC 而非 S3TC。
按 AGENTS.md「不自行补全关键参数」的要求，此处**保持官方原样未改**。
如果用户确认贴图在手机上不显示或全黑，应把该项改为 `true` 重新导出。

## 验证记录

最近一次编译时间：（见 GitHub Actions）
最近一次运行验证时间：（待用户实机确认）
仍需用户确认的内容：选人界面是否出现守烬人、能否开局、余烬是否正常叠层

## 相关记录

任务记录目录（按需）：
决策记录目录（按需）：
测试记录目录（按需）：
