#!/usr/bin/env bash
# 云端构建脚本 —— 由 GitHub Actions 调用
# 包含全部构建逻辑，这样仓库里的工作流文件只需十几行。
#
# 用法（在仓库根目录）：
#   unzip -q Emberkeeper.zip -d src && bash src/Emberkeeper/ci-build.sh

set -uo pipefail

echo "=========== 守烬人 Mod 云端构建 ==========="

# ── 定位源码目录 ──────────────────────────────────────────────
if [ -f "Emberkeeper.csproj" ]; then
    ROOT="$(pwd)"
elif [ -f "Emberkeeper/Emberkeeper.csproj" ]; then
    ROOT="$(pwd)/Emberkeeper"
else
    ROOT="$(dirname "$(find . -name 'Emberkeeper.csproj' -not -path '*/obj/*' | head -1)")"
    ROOT="$(cd "$ROOT" && pwd)"
fi

if [ -z "$ROOT" ] || [ ! -f "$ROOT/Emberkeeper.csproj" ]; then
    echo "::error::找不到 Emberkeeper.csproj，源码结构不对"
    find . -maxdepth 3 -name "*.csproj" || true
    exit 1
fi

echo "源码目录：$ROOT"
cd "$ROOT" || exit 1

OUT=/tmp/emberkeeper_out
rm -rf "$OUT"
mkdir -p "$OUT/Emberkeeper"

# ── 1. 编译 DLL ───────────────────────────────────────────────
echo ""
echo "=== [1/3] 编译 Emberkeeper.dll ==="
echo "--- restore ---"
dotnet restore -p:UseRefLib=true 2>&1 | tail -25
echo "--- build ---"
if ! dotnet build -c Release --no-restore -p:UseRefLib=true 2>&1 | tail -60; then
    echo "::error::编译失败"
    exit 1
fi

DLL=$(find . -name "Emberkeeper.dll" -not -path "*/obj/*" -not -path "*/bin/obj/*" | head -1)
if [ -z "$DLL" ]; then
    echo "::error::编译成功但没找到 Emberkeeper.dll"
    find . -name "*.dll" -newermt "-5 minutes" | head -20 || true
    exit 1
fi
echo "产物：$DLL"
cp "$DLL" "$OUT/Emberkeeper/Emberkeeper.dll"
cp Emberkeeper.json "$OUT/Emberkeeper/Emberkeeper.json"

# ── 2. 导出 PCK ───────────────────────────────────────────────
echo ""
echo "=== [2/3] 导出 Emberkeeper.pck ==="
cd /tmp
curl -sSL -o godot.zip \
  https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux_x86_64.zip
unzip -q -o godot.zip
mv Godot_v4.5.1-stable_linux_x86_64 godot-bin 2>/dev/null || true
chmod +x godot-bin
./godot-bin --version 2>/dev/null | head -1 || echo "(无法打印版本，继续)"

cd "$ROOT"
mkdir -p .hide
[ -d Code ] && mv Code .hide/Code
[ -f Emberkeeper.csproj ] && mv Emberkeeper.csproj .hide/

/tmp/godot-bin --headless --export-pack "BasicExport" Emberkeeper.pck 2>&1 | tail -20
PCK_OK=$?

[ -d .hide/Code ] && mv .hide/Code Code
[ -f .hide/Emberkeeper.csproj ] && mv .hide/Emberkeeper.csproj Emberkeeper.csproj

if [ $PCK_OK -eq 0 ] && [ -f Emberkeeper.pck ]; then
    cp Emberkeeper.pck "$OUT/Emberkeeper/Emberkeeper.pck"
    echo "✓ 完整版：dll + pck（专属立绘 + 中文）"
else
    cp Emberkeeper-NoPck.json "$OUT/Emberkeeper/Emberkeeper.json"
    echo "⚠ PCK 导出失败 → 退回精简版：仅 dll（美术沿用原版）"
fi

# ── 3. 打包 ───────────────────────────────────────────────────
echo ""
echo "=== [3/3] 打包 ==="
cd "$OUT"
zip -r Emberkeeper-mod.zip Emberkeeper
mkdir -p "$ROOT/out"
cp Emberkeeper-mod.zip "$ROOT/out/Emberkeeper-mod.zip"

echo ""
echo "=========== 成品清单 ==========="
ls -lh "$OUT/Emberkeeper/"
echo ""
echo "完成。下载 out/Emberkeeper-mod.zip 解压即可。"
