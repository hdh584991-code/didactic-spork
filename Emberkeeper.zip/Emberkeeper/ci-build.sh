#!/usr/bin/env bash
# ===================================================================
#  守烬人 Mod —— 云端构建
#
#  被 .github/workflows/main.yml 调用：
#      bash s/Emberkeeper/ci-build.sh
#
#  构建步骤严格对齐公开工作区官方脚本：
#    - DLL   ← 04-工具/工作流/build-native-mod.ps1 的做法
#              （bin/<Configuration> 下定位同名 DLL，并校验产物比源码新）
#    - PCK   ← 04-工具/工作流/pack-pck.ps1 的做法
#              （--headless --path <工程> --export-pack "<preset>" <输出>，
#                preset 取 export_presets.cfg 里的 name，默认是 "Windows Desktop"）
#
#  产物：<项目根>/out/Emberkeeper-mod.zip
#  全程 set +e：任何一步失败都继续，最后打印体检表，便于定位。
# ===================================================================

set +e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT" || exit 1

# 与 pack-pck.ps1 的默认预设保持一致；也和 export_presets.cfg 的 name 一致
PRESET="${PRESET:-Windows Desktop}"

echo "############ 守烬人 Mod 云端构建 ############"
echo "项目根 : $ROOT"
echo "预设名 : $PRESET"
echo

# ── 0. 环境核对 ────────────────────────────────────────────
echo "===== 0. 环境核对 ====="
dotnet --version 2>&1 | head -2
echo "脚本数 : $(find Scripts -name '*.cs' 2>/dev/null | wc -l)  (应 7)"
echo "贴图数 : $(find Emberkeeper/images -type f 2>/dev/null | wc -l)  (应 12)"
echo "工程文件: $(ls *.csproj 2>/dev/null | tr '\n' ' ')"
echo "清单    : $(ls *.json 2>/dev/null | tr '\n' ' ')"
echo "预设名  : $(grep -h '^name=' export_presets.cfg 2>/dev/null | tr '\n' ' ')"
echo

# ── 1. restore ─────────────────────────────────────────────
echo "===== 1. restore ====="
dotnet restore -p:UseRefLib=true 2>&1 | tail -25
echo "restore 退出码=${PIPESTATUS[0]}"
echo

# ── 2. build ───────────────────────────────────────────────
echo "===== 2. build ====="
dotnet build -c Release --no-restore -p:UseRefLib=true 2>&1 | tail -40
echo "build 退出码=${PIPESTATUS[0]}"
echo

# ── 3. 定位 DLL（对齐 build-native-mod.ps1）────────────────
#   官方做法：在 bin/<Configuration> 下递归找同名 DLL，
#             并校验 DLL 比最近修改的源码新，防止"编译成功但跑的是旧代码"。
echo "===== 3. 定位 DLL ====="
mkdir -p out/mods/Emberkeeper
DLL=$(find "bin/Release" -name "Emberkeeper.dll" -type f 2>/dev/null | head -1)
echo "DLL=[$DLL]"

if [ -n "$DLL" ] && [ -f "$DLL" ]; then
    NEWEST_SRC=$(find Scripts -name '*.cs' -type f -newer "$DLL" 2>/dev/null | head -1)
    if [ -n "$NEWEST_SRC" ]; then
        echo "⚠ 警告：有源码比 DLL 新（$NEWEST_SRC），产物可能是旧的"
    else
        echo "✓ DLL 不早于任何源码"
    fi
    cp "$DLL" out/mods/Emberkeeper/
    cp Emberkeeper.json out/mods/Emberkeeper/
    echo "DLL 已收"
else
    echo "!!!!!! 编译没产出 DLL !!!!!!"
fi
echo

# ── 4. 准备 Godot ──────────────────────────────────────────
echo "===== 4. 准备 Godot ====="
mkdir -p /tmp/gd && cd /tmp/gd
G=""
for U in \
  "https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux.x86_64.zip" \
  "https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux_x86_64.zip" ; do
    rm -f g.zip
    curl -sSL --max-time 300 -o g.zip "$U"
    SZ=$(stat -c%s g.zip 2>/dev/null || echo 0)
    echo "  $(basename "$U") → $SZ 字节"
    [ "$SZ" -lt 1000000 ] && continue
    unzip -q -o g.zip || continue
    C=$(find . -maxdepth 1 -type f -iname "Godot*" ! -name "*.zip" | head -1)
    if [ -n "$C" ]; then chmod +x "$C"; G="$(pwd)/$C"; echo "  ✔ Godot: $G"; break; fi
done
[ -n "$G" ] && "$G" --headless --version 2>&1 | head -2
echo "GODOT=[$G]"
cd "$ROOT"
echo

# ── 5. 导出 PCK（对齐 pack-pck.ps1）────────────────────────
#   官方做法：Godot 报告成功但文件不存在，也要判失败。
echo "===== 5. 导出 PCK ====="
mkdir -p Build
PCK_OK=0
if [ -n "$G" ]; then
    rm -f Build/Emberkeeper.pck
    "$G" --headless --path . --export-pack "$PRESET" "Build/Emberkeeper.pck" 2>&1 | tail -20
    RC=$?
    echo "export-pack 退出码=$RC"
    if [ -s "Build/Emberkeeper.pck" ]; then
        echo "✔ PCK 已生成（$(( $(stat -c%s Build/Emberkeeper.pck) / 1024 )) KB）"
        PCK_OK=1
    else
        echo "⚠ Godot 退出码=$RC 但没有产出 PCK"
    fi
else
    echo "⚠ 没有 Godot，跳过导出"
fi

if [ "$PCK_OK" = "1" ]; then
    cp Build/Emberkeeper.pck out/mods/Emberkeeper/
    echo "→ 完整版（自定义贴图生效）"
else
    echo "→ PCK 失败，回退精简版（沿用 silent 原版美术）"
    sed -i 's/UseCustomImages = true/UseCustomImages = false/' Scripts/Characters/EmberkeeperCharacter.cs
    grep -n "UseCustomImages = " Scripts/Characters/EmberkeeperCharacter.cs
    dotnet build -c Release --no-restore -p:UseRefLib=true 2>&1 | tail -12
    DLL2=$(find "bin/Release" -name "Emberkeeper.dll" -type f 2>/dev/null | head -1)
    [ -n "$DLL2" ] && cp "$DLL2" out/mods/Emberkeeper/
    cp Emberkeeper-NoPck.json out/mods/Emberkeeper/Emberkeeper.json
fi
echo

# ── 6. BaseLib 前置库 ──────────────────────────────────────
echo "===== 6. BaseLib 前置库 ====="
mkdir -p out/mods/BaseLib
for e in dll pck json; do
    curl -sSL --max-time 180 -o "out/mods/BaseLib/BaseLib.$e" \
      "https://github.com/Alchyr/BaseLib-StS2/releases/download/v3.4.7/BaseLib.$e"
    echo "  BaseLib.$e → $(stat -c%s "out/mods/BaseLib/BaseLib.$e" 2>/dev/null || echo 0) 字节"
done
echo

# ── 7. 打包 ────────────────────────────────────────────────
echo "===== 7. 打包 ====="
cd out
zip -r -q Emberkeeper-mod.zip mods
echo "zip 退出码=$?"
find mods -type f | sort
ls -lh Emberkeeper-mod.zip
cd "$ROOT"
echo

# ── 8. 体检表 ──────────────────────────────────────────────
echo "===== 8. 体检表 ====="
for M in Emberkeeper BaseLib; do
    D=$(ls "out/mods/$M"/*.dll  2>/dev/null | wc -l)
    P=$(ls "out/mods/$M"/*.pck  2>/dev/null | wc -l)
    J=$(ls "out/mods/$M"/*.json 2>/dev/null | wc -l)
    echo "  $M: dll=$D  pck=$P  json=$J"
done
echo
echo "===== 完成 ====="
echo "产物: $ROOT/out/Emberkeeper-mod.zip"
exit 0
