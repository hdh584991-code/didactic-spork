# 守烬人 Mod 一键构建（Windows / PowerShell）
# 自动完成：编译 DLL → 导出 PCK → 安装到 mods/Emberkeeper/
#
# 用法：在本脚本所在目录右键 → 使用 PowerShell 运行
# 前置：装好 .NET 9 SDK + Godot 4.5.1（见 README）

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "=== 守烬人 Mod 构建器 ===" -ForegroundColor Cyan
Write-Host ""

$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

# ── 1. 定位游戏目录 ────────────────────────────────────────────
Write-Host "[1/5] 定位游戏目录..." -ForegroundColor Yellow

$candidates = @(
    "C:\Program Files (x86)\Steam\steamapps\common\Slay the Spire 2",
    "C:\Program Files\Steam\steamapps\common\Slay the Spire 2",
    "D:\SteamLibrary\steamapps\common\Slay the Spire 2",
    "E:\SteamLibrary\steamapps\common\Slay the Spire 2",
    "F:\SteamLibrary\steamapps\common\Slay the Spire 2",
    "G:\SteamLibrary\steamapps\common\Slay the Spire 2"
)

$gameDir = $null
foreach ($p in $candidates) {
    if (Test-Path $p) { $gameDir = $p; break }
}
if (-not $gameDir) {
    $gameDir = (Read-Host "没找到游戏，请粘贴 Slay the Spire 2 的完整路径").Trim('"')
}
if (-not (Test-Path $gameDir)) {
    Write-Host "路径不存在：$gameDir" -ForegroundColor Red; exit 1
}
Write-Host "  $gameDir" -ForegroundColor Green

$dataDir  = Join-Path $gameDir "data_sts2_windows_x86_64"
$install  = Join-Path $gameDir "mods\Emberkeeper"

# ── 2. 检查 .NET SDK ───────────────────────────────────────────
Write-Host "[2/5] 检查 .NET 9 SDK..." -ForegroundColor Yellow

$sdkOk = $false
try {
    $sdks = & dotnet --list-sdks 2>$null
    if ($sdks) {
        foreach ($s in $sdks) { if ($s -like "9.*") { $sdkOk = $true; break } }
    }
} catch { }

if (-not $sdkOk) {
    Write-Host ""
    Write-Host "  没检测到 .NET 9 SDK。" -ForegroundColor Red
    Write-Host "  请到 https://dotnet.microsoft.com/download/dotnet/9.0 下载" -ForegroundColor Yellow
    Write-Host "  .NET 9.0 SDK（注意是 SDK，不是 Runtime），装完重跑本脚本。" -ForegroundColor Yellow
    exit 1
}
Write-Host "  SDK 就绪" -ForegroundColor Green

# 校验游戏 dll 存在
if (-not (Test-Path (Join-Path $dataDir "sts2.dll"))) {
    Write-Host "  找不到 $dataDir\sts2.dll，游戏目录可能不对" -ForegroundColor Red
    exit 1
}
# 校验 BaseLib
$baseLib = Join-Path $gameDir "mods\BaseLib\BaseLib.dll"
if (-not (Test-Path $baseLib)) {
    Write-Host "  找不到 BaseLib.dll，请先运行 tools\install_baselib.ps1" -ForegroundColor Red
    exit 1
}
Write-Host "  BaseLib 已就位" -ForegroundColor Green

# ── 3. 编译 DLL ────────────────────────────────────────────────
Write-Host "[3/5] 编译 Emberkeeper.dll ..." -ForegroundColor Yellow

# 生成 local.props
$props = @"
<Project>
  <PropertyGroup>
    <Sts2Dir>$gameDir</Sts2Dir>
  </PropertyGroup>
</Project>
"@
Set-Content -Path "local.props" -Value $props -Encoding UTF8

& dotnet build -c Release --nologo
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "  编译失败。请往上翻看具体报错。" -ForegroundColor Red
    Write-Host "  常见原因：README 第六节列出的 3 个 API 签名与本地 sts2.dll 不一致。" -ForegroundColor Yellow
    exit 1
}

New-Item -ItemType Directory -Path $install -Force | Out-Null
$dll = Get-ChildItem -Path "bin" -Filter "Emberkeeper.dll" -Recurse | Select-Object -First 1
if (-not $dll) { Write-Host "  没找到编译产物 Emberkeeper.dll" -ForegroundColor Red; exit 1 }
Copy-Item $dll.FullName (Join-Path $install "Emberkeeper.dll") -Force
Copy-Item "Emberkeeper.json" (Join-Path $install "Emberkeeper.json") -Force
Write-Host "  DLL 完成" -ForegroundColor Green

# ── 4. 定位 Godot ──────────────────────────────────────────────
Write-Host "[4/5] 定位 Godot 4.5.1 ..." -ForegroundColor Yellow

$godot = $null
foreach ($cmd in @("godot", "godot4")) {
    $c = Get-Command $cmd -ErrorAction SilentlyContinue
    if ($c) { $godot = $c.Source; break }
}
if (-not $godot) {
    $searchRoots = @("$env:LOCALAPPDATA\Programs", "C:\Program Files", "C:\", "D:\")
    foreach ($root in $searchRoots) {
        if (-not (Test-Path $root)) { continue }
        $hit = Get-ChildItem -Path $root -Filter "Godot*.exe" -Recurse -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -like "*4.5*" } | Select-Object -First 1
        if ($hit) { $godot = $hit.FullName; break }
    }
}
if (-not $godot) {
    $godot = (Read-Host "没找到 Godot，请粘贴 Godot 4.5.1 的 exe 完整路径").Trim('"')
}
if (-not (Test-Path $godot)) {
    Write-Host "  Godot 路径无效：$godot" -ForegroundColor Red
    Write-Host "  请到 https://godotengine.org/download/archive/ 下载 4.5.1" -ForegroundColor Yellow
    Write-Host "  （不要高于 4.5.1，否则 pck 会被游戏拒绝）" -ForegroundColor Yellow
    exit 1
}
Write-Host "  $godot" -ForegroundColor Green

# ── 5. 导出 PCK ────────────────────────────────────────────────
Write-Host "[5/5] 导出 Emberkeeper.pck ..." -ForegroundColor Yellow

# 临时隔离 C# 源码与 csproj，避免 Godot 尝试编译它们
$hid = @()
foreach ($item in @("Code", "Emberkeeper.csproj")) {
    if (Test-Path $item) {
        $tmp = "$item.__godot_hide"
        Move-Item $item $tmp -Force
        $hid += $tmp
    }
}

try {
    & $godot --headless --export-pack "BasicExport" "Emberkeeper.pck" 2>&1 | Out-Host
    $ok = $LASTEXITCODE -eq 0
} catch {
    $ok = $false
}

# 无论成败都还原
foreach ($tmp in $hid) {
    $orig = $tmp -replace '\.__godot_hide$', ''
    if (Test-Path $tmp) { Move-Item $tmp $orig -Force }
}

if (-not $ok -or -not (Test-Path "Emberkeeper.pck")) {
    Write-Host ""
    Write-Host "  自动导出失败。改用手动方式：" -ForegroundColor Red
    Write-Host "  1. Godot 4.5.1 打开本目录的 project.godot" -ForegroundColor Yellow
    Write-Host "  2. 项目 → 导出 → 添加 Windows Desktop" -ForegroundColor Yellow
    Write-Host "  3. 点 导出 PCK/ZIP，存为 Emberkeeper.pck" -ForegroundColor Yellow
    Write-Host "  4. 把 pck 拷到 $install" -ForegroundColor Yellow
    exit 1
}

Copy-Item "Emberkeeper.pck" (Join-Path $install "Emberkeeper.pck") -Force
Write-Host "  PCK 完成" -ForegroundColor Green

# ── 收尾 ───────────────────────────────────────────────────────
Write-Host ""
Write-Host "=== 安装完成 ===" -ForegroundColor Cyan
Write-Host "  $install"
Get-ChildItem $install | ForEach-Object { Write-Host "  $($_.Name)  ($([math]::Round($_.Length/1KB,1)) KB)" }

Write-Host ""
Write-Host "现在用 Play with Mods 启动游戏，Mods 菜单勾选「守烬人 Emberkeeper」，重启即可。" -ForegroundColor Cyan
Write-Host ""
Read-Host "按回车键退出"
