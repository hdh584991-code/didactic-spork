using System;
using System.Linq;
using System.Reflection;

// 反射探测：把 sts2 / BaseLib 里真实的 API 签名打印出来。
// 目的：拿到 PowerModel / CustomPowerModel 上「回合开始」钩子的真实名字和签名，
//      用来补回 EmberPower 的「余烬 → 格挡」转化。
// 依据：AGENTS.md 第 1 节——当前版本程序集优先于教程和印象。
class P
{
    static void Main()
    {
        Assembly? sts2 = null, baselib = null;
        foreach (var name in new[] { "sts2", "BaseLib" })
        {
            try
            {
                var a = Assembly.Load(name);
                if (name == "sts2") sts2 = a; else baselib = a;
            }
            catch (Exception e) { Console.WriteLine($"(加载 {name} 失败: {e.Message})"); }
        }

        // [A] PowerModel 上所有可重写的钩子（名字含 Turn / After / Before）
        DumpVirtuals(sts2, "MegaCrit.Sts2.Core.Models.PowerModel", "A. sts2 PowerModel 钩子",
            m => m.Name.Contains("Turn") || m.Name.StartsWith("After") || m.Name.StartsWith("Before"));

        // [B] BaseLib CustomPowerModel 上所有可重写的钩子
        DumpVirtuals(baselib, "BaseLib.Abstracts.CustomPowerModel", "B. BaseLib CustomPowerModel 钩子",
            m => m.Name.Contains("Turn") || m.Name.StartsWith("After") || m.Name.StartsWith("Before"));

        // [C] PowerCmd 的真实签名
        Dump(sts2, "MegaCrit.Sts2.Core.Commands.PowerCmd", "C. PowerCmd", m => m.Name is "Apply" or "Remove");

        // [D] CreatureCmd.GainBlock
        Dump(sts2, "MegaCrit.Sts2.Core.Commands.CreatureCmd", "D. CreatureCmd", m => m.Name == "GainBlock");

        // [E] BaseLib 里是否存在 Pool 特性（教程用的 [Pool(typeof(X))]）
        Console.WriteLine("===== E. BaseLib Pool 特性 =====");
        if (baselib != null)
        {
            var hits = baselib.GetTypes()
                .Where(t => t.Name.StartsWith("Pool") && t.Name.Contains("Attribute"))
                .Select(t => t.FullName);
            foreach (var h in hits) Console.WriteLine("  找到: " + h);
            if (!hits.Any()) Console.WriteLine("  (未找到 Pool*Attribute，教程写法可能与此版本不符)");
        }

        // [F] CustomCardModel 的卡图属性名
        DumpProps(baselib, "BaseLib.Abstracts.CustomCardModel", "F. CustomCardModel 属性",
            p => p.Name.Contains("Portrait") || p.Name.Contains("Icon"));
        DumpProps(sts2, "MegaCrit.Sts2.Core.Models.CardModel", "F2. sts2 CardModel 属性",
            p => p.Name.Contains("Portrait"));

        // [G] CustomRelicModel 图标属性
        DumpProps(baselib, "BaseLib.Abstracts.CustomRelicModel", "G. CustomRelicModel 属性",
            p => p.Name.Contains("Icon"));

        // [H] CustomPowerModel 图标属性
        DumpProps(baselib, "BaseLib.Abstracts.CustomPowerModel", "H. CustomPowerModel 属性",
            p => p.Name.Contains("Icon"));
    }

    static void DumpVirtuals(Assembly? asm, string typeName, string tag, Func<MethodInfo, bool> filter)
    {
        Console.WriteLine($"===== {tag} ({typeName}) =====");
        if (asm == null) { Console.WriteLine("  (程序集未加载)"); return; }
        var t = asm.GetType(typeName);
        if (t == null) { Console.WriteLine("  (未找到类型)"); return; }
        var ms = t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                  .Where(m => m.IsVirtual && !m.IsSpecialName && filter(m))
                  .OrderBy(m => m.Name);
        foreach (var m in ms)
        {
            var ps = string.Join(", ", m.GetParameters().Select(p => Short(p.ParameterType) + " " + p.Name));
            Console.WriteLine($"  {Short(m.ReturnType)} {m.Name}({ps})");
        }
        if (!ms.Any()) Console.WriteLine("  (无匹配方法)");
    }

    static void Dump(Assembly? asm, string typeName, string tag, Func<MethodInfo, bool> filter)
    {
        Console.WriteLine($"===== {tag} ({typeName}) =====");
        if (asm == null) { Console.WriteLine("  (程序集未加载)"); return; }
        var t = asm.GetType(typeName);
        if (t == null) { Console.WriteLine("  (未找到类型)"); return; }
        foreach (var m in t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static)
                 .Where(filter).OrderBy(m => m.Name))
        {
            var ps = string.Join(", ", m.GetParameters().Select(p => Short(p.ParameterType) + " " + p.Name));
            Console.WriteLine($"  {Short(m.ReturnType)} {m.Name}({ps})");
        }
    }

    static void DumpProps(Assembly? asm, string typeName, string tag, Func<PropertyInfo, bool> filter)
    {
        Console.WriteLine($"===== {tag} ({typeName}) =====");
        if (asm == null) { Console.WriteLine("  (程序集未加载)"); return; }
        var t = asm.GetType(typeName);
        if (t == null) { Console.WriteLine("  (未找到类型)"); return; }
        foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                 .Where(filter).OrderBy(p => p.Name))
        {
            Console.WriteLine($"  {Short(p.PropertyType)} {p.Name}  (virtual={p.GetMethod?.IsVirtual})");
        }
    }

    static string Short(Type t)
    {
        var n = t.Name;
        if (t.IsGenericType)
            n = n.Split('`')[0] + "<" + string.Join(",", t.GetGenericArguments().Select(Short)) + ">";
        return n;
    }
}
