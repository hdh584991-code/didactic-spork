using System;
using System.Linq;
using System.Reflection;

// 反射探测：把 sts2 / BaseLib 里真实的 API 签名打印出来。
// 目的是拿到 PowerModel 的回合开始钩子名，用来补回「余烬 → 格挡」的转化。
class P
{
    static void Main()
    {
        var sts2 = Assembly.Load("sts2");

        Console.WriteLine("===== PowerModel 回合钩子 =====");
        var pm = sts2.GetType("MegaCrit.Sts2.Core.Models.PowerModel");
        if (pm != null)
        {
            foreach (var m in pm.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                     .Where(m => m.IsVirtual && m.Name.Contains("Turn")).OrderBy(m => m.Name))
            {
                var ps = string.Join(", ", m.GetParameters().Select(p => p.ParameterType.Name + " " + p.Name));
                Console.WriteLine($"{m.ReturnType.Name} {m.Name}({ps})");
            }
        }
        else Console.WriteLine("(未找到 PowerModel)");

        Dump(sts2, "MegaCrit.Sts2.Core.Commands.PowerCmd", "PowerCmd", m => m.Name is "Apply" or "Remove");
        Dump(sts2, "MegaCrit.Sts2.Core.Commands.CreatureCmd", "CreatureCmd", m => m.Name == "GainBlock");
        Dump(sts2, "MegaCrit.Sts2.Core.Commands.DamageCmd", "DamageCmd", m => m.Name == "Attack");
    }

    static void Dump(Assembly asm, string typeName, string tag, Func<MethodInfo, bool> filter)
    {
        Console.WriteLine($"===== {tag} ({typeName}) =====");
        var t = asm.GetType(typeName);
        if (t == null) { Console.WriteLine("(未找到)"); return; }
        foreach (var m in t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static)
                 .Where(filter).OrderBy(m => m.Name))
        {
            var ps = string.Join(", ", m.GetParameters().Select(p => p.ParameterType.Name + " " + p.Name));
            Console.WriteLine($"{m.ReturnType.Name} {m.Name}({ps})");
        }
    }
}
