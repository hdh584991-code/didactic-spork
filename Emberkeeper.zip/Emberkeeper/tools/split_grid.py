#!/usr/bin/env python3
"""
把 1920×1920 的九宫格大图切成 9 张贴图，并按目标尺寸归位。

用法（在项目根目录）：
    python3 Emberkeeper/tools/split_grid.py 大图.png

输出：直接写进 Emberkeeper/Emberkeeper/images/ 对应目录。

处理流程：
  1. 按 3×3 网格切格
  2. 自动 trim 掉纯黑 / 透明的空白边（所以格子里留白多少都无所谓）
  3. 等比缩放后居中贴到目标画布上（不拉伸变形），透明底
"""

import sys
import os
from PIL import Image, ImageDraw, ImageFilter

# (行, 列) -> (输出相对路径, 目标宽, 目标高)
LAYOUT = {
    (0, 0): ("char_select_emberkeeper.png",        640, 480),
    (0, 1): ("char_select_emberkeeper_locked.png", 640, 480),
    (0, 2): ("character_placeholder.png",          256, 256),
    (1, 0): ("cards/EmberStrike.png",              250, 190),
    (1, 1): ("cards/EmberDefend.png",              250, 190),
    (1, 2): ("cards/EmberBurst.png",               250, 190),
    (2, 0): ("relics/emberheart.png",              256, 256),
    (2, 1): ("powers/ember.png",                   256, 256),
    (2, 2): ("energy_ember_big.png",                74,  74),
}

# 由能量球大图派生的小图
DERIVE = [
    ("energy_ember_big.png", "energy_ember.png", 24, 24),
    ("powers/ember.png",     "mod_image.png",   256, 256),
]


def trim(img, tol=18):
    """裁掉纯黑或透明的边距。"""
    img = img.convert("RGBA")
    alpha = img.split()[-1]
    # 用 alpha 通道找边界；若整图不透明，则按接近纯黑判断
    bbox_alpha = alpha.getbbox()
    if bbox_alpha is None:
        return img
    # 只考虑非透明区域里"不是纯黑"的部分
    rgb = img.convert("RGB")
    w, h = img.size
    px = rgb.load()
    ap = alpha.load()
    left, top, right, bottom = w, h, 0, 0
    found = False
    step = 2
    for y in range(0, h, step):
        for x in range(0, w, step):
            if ap[x, y] < 10:
                continue
            r, g, b = px[x, y]
            if max(r, g, b) <= tol:
                continue
            found = True
            left = min(left, x); right = max(right, x)
            top = min(top, y);  bottom = max(bottom, y)
    if not found:
        return img
    pad = 2
    left = max(0, left - pad); top = max(0, top - pad)
    right = min(w, right + pad); bottom = min(h, bottom + pad)
    return img.crop((left, top, right, bottom))


def fit(img, tw, th):
    """等比缩放后居中贴到 tw×th 的透明画布上（不拉伸）。"""
    img = img.convert("RGBA")
    iw, ih = img.size
    if iw == 0 or ih == 0:
        return Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    scale = min(tw / iw, th / ih)
    nw, nh = max(1, int(iw * scale)), max(1, int(ih * scale))
    resized = img.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    canvas.paste(resized, ((tw - nw) // 2, (th - nh) // 2), resized)
    return canvas


def main():
    if len(sys.argv) < 2:
        print("用法: python3 split_grid.py 大图.png")
        sys.exit(1)

    src_path = sys.argv[1]
    src = Image.open(src_path)
    W, H = src.size
    print(f"源图: {src_path}  {W}×{H}")

    # 自动判断格子尺寸（兼容 1920×1920，也兼容别的总尺寸）
    cell_w, cell_h = W // 3, H // 3
    print(f"格子: {cell_w}×{cell_h}")

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out_dir = os.path.join(root, "Emberkeeper", "images")
    os.makedirs(out_dir, exist_ok=True)

    produced = []
    for (r, c), (rel, tw, th) in sorted(LAYOUT.items()):
        box = (c * cell_w, r * cell_h, (c + 1) * cell_w, (r + 1) * cell_h)
        cell = src.crop(box)
        cell = trim(cell)
        cell = fit(cell, tw, th)
        out_path = os.path.join(out_dir, rel)
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        cell.save(out_path)
        produced.append((rel, tw, th))
        print(f"  ✓ [{r},{c}] {rel}  ({tw}×{th})")

    for src_rel, dst_rel, tw, th in DERIVE:
        s = os.path.join(out_dir, src_rel)
        if not os.path.exists(s):
            continue
        im = Image.open(s).convert("RGBA")
        im = fit(im, tw, th)
        dst = os.path.join(out_dir, dst_rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        im.save(dst)
        produced.append((dst_rel, tw, th))
        print(f"  ✓ 派生 {dst_rel}  ({tw}×{th})")

    # 遗物白色描边图：取 alpha 轮廓做成白色剪影
    relic = os.path.join(out_dir, "relics", "emberheart.png")
    if os.path.exists(relic):
        im = Image.open(relic).convert("RGBA")
        a = im.split()[-1]
        mask = a.point(lambda v: 255 if v > 40 else 0)
        # 稍微膨胀一点，视觉上更像"描边"
        grown = mask.filter(ImageFilter.MaxFilter(5))
        outline = Image.new("RGBA", im.size, (0, 0, 0, 0))
        outline.paste((255, 255, 255, 255), (0, 0), grown)
        dst = os.path.join(out_dir, "relics", "emberheart_outline.png")
        outline.save(dst)
        produced.append(("relics/emberheart_outline.png", im.size[0], im.size[1]))
        print("  ✓ 派生 relics/emberheart_outline.png")

    print(f"\n完成，共 {len(produced)} 个文件 → {out_dir}")


if __name__ == "__main__":
    main()
