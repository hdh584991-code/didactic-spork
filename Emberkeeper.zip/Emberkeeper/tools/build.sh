#!/usr/bin/env bash
# 守烬人 Mod 一键构建（macOS / Linux）
# 自动完成：编译 DLL → 导出 PCK → 安装到 mods/Emberkeeper/
#
# 用法：chmod +x build.sh && ./build.sh
# 前置：装好 .NET 9 SDK + Godot 4.5.1（见 README）

set -uo pipefail

echo "=== 守烬人 Mod 构建器 ==="
echo ""

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT" || exit 1

# ── 1. 定位游戏目录 ────────────────────────────────────────────
echo "[1/5] 定位游戏目录..."

if [[ "$(uname)" == "Darwin" ]]; then
    GAME_DIR="$HOME/Library/Application Support/Steam/steamapps/common/Slay the Spire 2/SlayTheSpire2.app/Contents/MacOS"
    DATA_DIR="$HOME/Library/Application Support/Steam/steamapps/common/Slay the Spire 2/SlayTheSpire2.app/Contents/Resources/data_sts2_macos_arm64"
    [[ -d "$DATA_DIR" ]] || DATA_DIR="$(dirname "$GAME_DIR")/Resources/data_sts2_macos_x86_64"
else
    GAME_DIR="$HOME/.steam/steam/steamapps/common/Slay the Spire 2"
    DATA_DIR="$GAME_DIR/data_sts2_linuxbsd_x86_64"
fi

if [[ ! -d "$GAME_DIR" ]]; then
    read -rp "没找到游戏，请粘贴 Slay the Spire 2 的路径（mac 请指到 Contents/MacOS）： " GAME_DIR
    GAME_DIR="${GAME_DIR%\"}"; GAME_DIR="${GAME_DIR#\"}"
fi
[[ -d "$GAME_DIR" ]] || { echo "路径不存在：$GAME_DIR"; exit 1; }

# 自动探测 data 目录
if [[ ! -d "$DATA_DIR" ]]; then
    DATA_DIR=$(find "$GAME_DIR" "$(dirname "$GAME_DIR")" -maxdepth 3 -type d -name "data_sts2_*" 2>/dev/null | head -1)
fi
[[ -n "$DATA_DIR" && -d "$DATA_DIR" ]] || { echo "找不到 data_sts2_* 目录"; exit 1; }

echo "  游戏：$GAME_DIR"
echo "  数据：$DATA_DIR"

INSTALL="$GAME_DIR/mods/Emberkeeper"

# ── 2. 检查 .NET SDK ───────────────────────────────────────────
echo "[2/5] 检查 .NET 9 SDK..."

if ! command -v dotnet >/dev/null 2>&1; then
    echo "  没装 dotnet。请到 https://dotnet.microsoft.com/download/dotnet/9.0 装 .NET 9.0 SDK"
    exit 1
fi
if ! dotnet --list-sdks 2>/dev/null | grep -q "^9\."; then
    echo "  没检测到 .NET 9 SDK（需要 SDK，不是 Runtime）。"
    echo "  下载地址：https://dotnet.microsoft.com/download/dotnet/9.0"
    exit 1
fi
echo "  SDK 就绪"

[[ -f "$DATA_DIR/sts2.dll" ]] || { echo "  找不到 sts2.dll：$DATA_DIR"; exit 1; }
[[ -f "$GAME_DIR/mods/BaseLib/BaseLib.dll" ]] || {
    echo "  找不到 BaseLib.dll，请先运行 tools/install_baselib.sh"; exit 1; }
echo "  BaseLib 已就位"

# ── 3. 编译 DLL ────────────────────────────────────────────────
echo "[3/5] 编译 Emberkeeper.dll ..."

cat > local.props <<EOF
<Project>
  <PropertyGroup>
    <Sts2Dir>$GAME_DIR</Sts2Dir>
    <Sts2DataDir>$DATA_DIR</Sts2DataDir>
  </PropertyGroup>
</Project>
EOF

if ! dotnet build -c Release --nologo; then
    echo ""
    echo "  编译失败。请往上翻看具体报错。"
    echo "  常见原因：README 第六节列出的 3 个 API 签名与本地 sts2.dll 不一致。"
    exit 1
fi

mkdir -p "$INSTALL"
DLL=$(find bin -name "Emberkeeper.dll" 2>/dev/null | head -1)
[[ -n "$DLL" ]] || { echo "  没找到编译产物 Emberkeeper.dll"; exit 1; }
cp "$DLL" "$INSTALL/Emberkeeper.dll"
cp Emberkeeper.json "$INSTALL/Emberkeeper.json"
echo "  DLL 完成"

# ── 4. 定位 Godot ──────────────────────────────────────────────
echo "[4/5] 定位 Godot 4.5.1 ..."

GODOT=""
for c in godot godot4 godot-4.5.1; do
    if command -v "$c" >/dev/null 2>&1; then GODOT=$(command -v "$c"); break; fi
done
if [[ -z "$GODOT" ]]; then
    if [[ "$(uname)" == "Darwin" ]]; then
        GODOT=$(find /Applications "$HOME/Applications" -maxdepth 2 -name "Godot*.app" 2>/dev/null | grep -i "4.5" | head -1)
        [[ -n "$GODOT" ]] && GODOT="$GODOT/Contents/MacOS/Godot"
    else
        GODOT=$(find "$HOME" /opt /usr/local -maxdepth 4 -type f -name "Godot*" 2>/dev/null | grep -i "4.5" | head -1)
    fi
fi
if [[ -z "$GODOT" || ! -x "$GODOT" ]]; then
    read -rp "没找到 Godot，请粘贴 Godot 4.5.1 可执行文件的完整路径： " GODOT
    GODOT="${GODOT%\"}"; GODOT="${GODOT#\"}"
fi
if [[ ! -x "$GODOT" ]]; then
    echo "  Godot 无效：$GODOT"
    echo "  请到 https://godotengine.org/download/archive/ 下载 4.5.1（不要更高版本）"
    exit 1
fi
echo "  $GODOT"

# ── 5. 导出 PCK ────────────────────────────────────────────────
echo "[5/5] 导出 Emberkeeper.pck ..."

# 临时隔离 C# 源码与 csproj，避免 Godot 尝试编译
HID=()
for item in Code Emberkeeper.csproj; do
    if [[ -e "$item" ]]; then
        mv "$item" "$item.__godot_hide"
        HID+=("$item.__godot_hide")
    fi
done

"$GODOT" --headless --export-pack "BasicExport" "Emberkeeper.pck"
RC=$?

# 还原
for tmp in "${HID[@]:-}"; do
    [[ -n "$tmp" ]] || continue
    orig="${tmp%.__godot_hide}"
    [[ -e "$tmp" ]] && mv "$tmp" "$orig"
done

if [[ $RC -ne 0 || ! -f Emberkeeper.pck ]]; then
    echo ""
    echo "  自动导出失败。改用手动方式："
    echo "  1. Godot 4.5.1 打开本目录的 project.godot"
    echo "  2. 项目 → 导出 → 添加 Windows Desktop"
    echo "  3. 点 导出 PCK/ZIP，存为 Emberkeeper.pck"
    echo "  4. 拷到 $INSTALL"
    exit 1
fi

cp Emberkeeper.pck "$INSTALL/Emberkeeper.pck"
echo "  PCK 完成"

# ── 收尾 ───────────────────────────────────────────────────────
echo ""
echo "=== 安装完成 ==="
echo "  $INSTALL"
ls -lh "$INSTALL" | tail -n +2 | awk '{print "  "$9"  ("$5")"}'

echo ""
echo "现在用 Play with Mods 启动游戏，Mods 菜单勾选「守烬人 Emberkeeper」，重启即可。"
