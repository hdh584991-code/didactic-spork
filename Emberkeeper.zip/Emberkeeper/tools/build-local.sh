#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════
#  守烬人 Mod —— 本地一键构建
#  适用：Linux / macOS / Termux(proot 里)
#
#  不需要游戏目录！用 NuGet 上的公开引用程序集编译。
#  产出：out/mods/BaseLib + out/mods/Emberkeeper + zip
#
#  用法：bash tools/build-local.sh
# ════════════════════════════════════════════════════════════

set +e   # 不因单条命令失败而中断，保证回退逻辑能跑完

echo "═══════ 守烬人 Mod 本地构建 ═══════"
echo

# ── 定位项目根 ──────────────────────────────────────────────
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1
echo "项目根目录: $ROOT"

# ── 1. 检查 dotnet ──────────────────────────────────────────
echo
echo "[1/5] 检查 .NET 9 SDK..."
if ! command -v dotnet >/dev/null 2>&1; then
    echo "  ❌ 没装 dotnet"
    echo "  安装：https://dotnet.microsoft.com/download/dotnet/9.0 （选 SDK）"
    exit 1
fi
if ! dotnet --list-sdks 2>/dev/null | grep -q "^9\."; then
    echo "  ❌ 检测到 dotnet 但没有 9.x SDK："
    dotnet --list-sdks 2>/dev/null | sed 's/^/     /'
    exit 1
fi
echo "  ✔ $(dotnet --version)"

# ── 2. 编译 DLL ─────────────────────────────────────────────
echo
echo "[2/5] 编译 Emberkeeper.dll ..."
echo "  (使用 NuGet 公开引用程序集，不需要游戏本体)"
if ! dotnet restore -p:UseRefLib=true 2>&1 | tail -5; then
    echo "  ❌ restore 失败（检查网络能否访问 nuget.org）"
    exit 1
fi
if ! dotnet build -c Release --no-restore -p:UseRefLib=true 2>&1 | tail -30; then
    echo "  ❌ 编译失败，上面是完整错误"
    exit 1
fi

mkdir -p out/mods/Emberkeeper
DLL=$(find . -name "Emberkeeper.dll" -not -path "*/obj/*" | head -1)
if [ -z "$DLL" ]; then
    echo "  ❌ 编译成功但找不到 Emberkeeper.dll"
    exit 1
fi
cp "$DLL" out/mods/Emberkeeper/
cp Emberkeeper.json out/mods/Emberkeeper/
echo "  ✔ DLL 完成"

# ── 3. 找 Godot（不猜文件名，用 glob）─────────────────────────
echo
echo "[3/5] 准备 Godot ..."
GODOT=""
# 先找系统里已有的
for c in godot godot4 godot-4.5.1; do
    if command -v "$c" >/dev/null 2>&1; then GODOT=$(command -v "$c"); break; fi
done

if [ -z "$GODOT" ]; then
    ARCH=$(uname -m)
    echo "  系统里没有 Godot，架构=$ARCH，尝试下载..."
    mkdir -p /tmp/gd && cd /tmp/gd
    case "$ARCH" in
        x86_64|amd64) CAND_URLS=(
            "https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux.x86_64.zip"
            "https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux_x86_64.zip"
        );;
        aarch64|arm64) CAND_URLS=(
            "https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux_arm64.zip"
            "https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux.arm64.zip"
        );;
        *) CAND_URLS=(
            "https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux.x86_64.zip"
        );;
    esac

    for URL in "${CAND_URLS[@]}"; do
        echo "  尝试: $(basename "$URL")"
        rm -f g.zip
        curl -sSL --max-time 300 -o g.zip "$URL" || { echo "    下载失败"; continue; }
        SZ=$(stat -c%s g.zip 2>/dev/null || echo 0)
        echo "    下载 $SZ 字节"
        [ "$SZ" -lt 1000000 ] && { echo "    文件太小，跳过"; continue; }
        unzip -q -o g.zip || { echo "    解压失败"; continue; }
        # glob 找真正的可执行文件
        CAND=$(find . -maxdepth 1 -type f \( -iname "Godot*" -o -iname "godot*" \) ! -name "*.zip" | head -1)
        if [ -n "$CAND" ]; then
            chmod +x "$CAND"
            GODOT="$(pwd)/$CAND"
            echo "    ✔ 找到: $GODOT"
            break
        fi
    done
    cd "$ROOT"
fi

if [ -n "$GODOT" ]; then
    echo "  Godot: $GODOT"
    "$GODOT" --headless --version 2>&1 | head -2
else
    echo "  ⚠ 没找到 Godot，将跳过 pck（会得到仅 dll 的精简版）"
fi

# ── 4. 导出 PCK ─────────────────────────────────────────────
echo
echo "[4/5] 导出 Emberkeeper.pck ..."
PCK_MADE=0
if [ -n "$GODOT" ]; then
    # 藏起含 .cs 的目录，避免 Godot 尝试编译 C#
    mkdir -p .h
    [ -d Code ] && mv Code .h/Code
    [ -d tools ] && mv tools .h/tools
    [ -f Emberkeeper.csproj ] && mv Emberkeeper.csproj .h/

    echo "  === 导入资源 ==="
    "$GODOT" --headless --path . --import > /tmp/imp.log 2>&1
    tail -15 /tmp/imp.log | sed 's/^/    /'

    for PRESET in BasicExport CustomExport MinimalExport; do
        echo "  === 尝试预设: $PRESET ==="
        rm -f Emberkeeper.pck
        "$GODOT" --headless --path . --export-pack "$PRESET" Emberkeeper.pck > /tmp/exp.log 2>&1
        tail -15 /tmp/exp.log | sed 's/^/    /'
        if [ -f Emberkeeper.pck ] && [ -s Emberkeeper.pck ]; then
            echo "    ✔ 成功：$PRESET"
            PCK_MADE=1
            break
        fi
    done

    # 还原
    [ -d .h/Code ] && mv .h/Code Code
    [ -d .h/tools ] && mv .h/tools tools
    [ -f .h/Emberkeeper.csproj ] && mv .h/Emberkeeper.csproj Emberkeeper.csproj
fi

if [ "$PCK_MADE" = "1" ]; then
    cp Emberkeeper.pck out/mods/Emberkeeper/
    echo "  ✔ PCK 完成 → 完整版（自定义贴图）"
else
    echo "  ⚠ PCK 失败 → 改用原版美术重编译（has_pck=false）"
    sed -i 's/UseCustomArt = true/UseCustomArt = false/' Code/Characters/EmberkeeperCharacter.cs
    dotnet build -c Release --no-restore -p:UseRefLib=true 2>&1 | tail -8
    DLL2=$(find . -name "Emberkeeper.dll" -not -path "*/obj/*" | head -1)
    [ -n "$DLL2" ] && cp "$DLL2" out/mods/Emberkeeper/
    cp Emberkeeper-NoPck.json out/mods/Emberkeeper/Emberkeeper.json
    echo "  已回退精简版"
fi

# ── 5. 准备 BaseLib + 打包 ──────────────────────────────────
echo
echo "[5/5] 准备 BaseLib 并打包 ..."
mkdir -p out/mods/BaseLib
for ext in dll pck json; do
    if [ ! -f "out/mods/BaseLib/BaseLib.$ext" ]; then
        echo "  下载 BaseLib.$ext ..."
        curl -sSL --max-time 180 -o "out/mods/BaseLib/BaseLib.$ext" \
            "https://github.com/Alchyr/BaseLib-StS2/releases/download/v3.4.7/BaseLib.$ext"
    fi
done

echo
echo "═══════ 成品 ═══════"
find out/mods -type f | sort | while read f; do
    printf "  %-42s %s\n" "$f" "$(du -h "$f" | cut -f1)"
done

cd out && zip -r -q Emberkeeper-mod.zip mods && cd ..
echo
echo "═══════ 完成 ═══════"
echo "  $ROOT/out/Emberkeeper-mod.zip"
echo
echo "解压后把 mods/ 里的 BaseLib 和 Emberkeeper 两个文件夹"
echo "一起丢进：Slay the Spire 2/mods/"
echo
