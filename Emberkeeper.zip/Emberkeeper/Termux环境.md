# 在 Termux 上装构建环境

先说清楚一个坑，免得白折腾：

## ⚠️ Termux 直接装 .NET 跑不起来

Termux 用的是 **Bionic libc**（Android 的 C 库），而 .NET 官方二进制依赖 **glibc**。两者不兼容，直接 `apt install dotnet` 或下载官方包会报 `cannot execute: required file not found` 之类的错。

**解决办法：用 proot-distro 装一个完整的 Linux 发行版**（里面有真正的 glibc），然后在里面装 .NET 和 Godot。

---

## 步骤（约 20~30 分钟，主要是下载）

### ① 装 proot-distro 并装 Ubuntu

```bash
pkg update && pkg upgrade -y
pkg install proot-distro -y
proot-distro install ubuntu
```

装完进入：

```bash
proot-distro login ubuntu
```

进去之后你就在一个正常的 Ubuntu 里了，后面所有操作都在这里面做。

> 以后每次重新打开 Termux 都要先 `proot-distro login ubuntu`。
> 想退出就 `exit`。

### ② 装 .NET 9 SDK

在 Ubuntu 里：

```bash
apt update
apt install -y curl wget unzip zip ca-certificates
curl -sSL https://dot.net/v1/dotnet-install.sh -o dotnet-install.sh
chmod +x dotnet-install.sh
./dotnet-install.sh --channel 9.0 --install-dir /usr/share/dotnet
echo 'export DOTNET_ROOT=/usr/share/dotnet' >> ~/.bashrc
echo 'export PATH=$PATH:/usr/share/dotnet' >> ~/.bashrc
export DOTNET_ROOT=/usr/share/dotnet
export PATH=$PATH:/usr/share/dotnet
dotnet --version
```

看到 `9.0.xxx` 就成了。

> 手机是 arm64 的话，上面的脚本会自动拉 linux-arm64 版本，没问题。
> 如果 apt 装的 dotnet 版本不对，用这个官方脚本最稳。

### ③ Godot（只在你想要自定义贴图时才需要）

如果 **不需要自定义贴图**，可以跳过这步——脚本会自动回退成仅 dll 的精简版，角色借用原版美术，照样能玩。

需要的话，构建脚本会**自动下载**对应架构的 Godot（arm64 会下 `linux_arm64` 版），你不用手动装。

想手动确认也行：

```bash
cd /tmp
curl -sSL -o g.zip https://github.com/godotengine/godot/releases/download/4.5.1-stable/Godot_v4.5.1-stable_linux_arm64.zip
unzip -q -o g.zip
chmod +x Godot*
./Godot* --headless --version
```

⚠️ 版本必须是 **4.5.1**，高于这个版本打出的 pck 游戏会拒绝加载。

---

## 开始构建

把项目文件夹弄进 Ubuntu 环境（几种办法任选）：

- `termux-setup-storage` 后从 `/sdcard/` 拷
- 或者直接在 Ubuntu 里 `git clone` 你的仓库
- 或者 `curl` 下载

然后：

```bash
cd Emberkeeper
bash tools/build-local.sh
```

脚本会自动做完全部事情：编译 → 导出 pck → 下载 BaseLib → 打包。

---

## 产物在哪

```
Emberkeeper/out/Emberkeeper-mod.zip
└── mods/
    ├── BaseLib/      (dll + json + pck)
    └── Emberkeeper/  (dll + json + pck)
```

把这个 zip 传到电脑上（微信/QQ/数据线都行），解压后把两个文件夹丢进游戏 `mods/` 目录。

---

## 可能遇到的问题

**`dotnet: command not found`**
→ 忘了 `export PATH`。重新执行一次那两行 export，或者重开 `proot-distro login ubuntu`。

**restore 失败 / 网络超时**
→ NuGet 访问不畅。脚本需要访问 nuget.org，手机网络一般没问题，Wi-Fi 不行换流量试试。

**Godot 下载失败**
→ 不影响，脚本会自动跳过 pck，给你精简版。

**手机发烫 / 内存不足**
→ 编译 .NET 比较吃资源。建议关掉其他 App，锁屏别让系统杀后台。编译一般 1~3 分钟。

---

## 值得吗？

说实话：如果只是想拿到能玩的 mod，**GitHub Actions 更省事**——我已经修好了 Godot 文件名那个 bug，你推上去跑一次就行，不用装任何东西。

Termux 本地构建的价值是**迭代快**：以后改个数值、加张卡，本地几秒钟就能出 dll，不用每次打包上传等 Actions。适合你打算长期折腾这个 mod 的情况。
