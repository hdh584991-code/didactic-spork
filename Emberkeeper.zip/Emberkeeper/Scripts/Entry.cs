using System;
using System.Reflection;
using Godot.Bridge;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Modding;

namespace Emberkeeper.Scripts;

/// <summary>
/// 守烬人 mod 入口。
///
/// 游戏会扫描程序集里带 [ModInitializer] 的类型，
/// 并调用特性参数中指定名字的静态初始化方法。
///
/// 按「05-模板/原生模组模板/Scripts/Entry.cs」实测注释：
/// 本方法运行在 ModelDb.Init 之前，此刻 ModelDb 还没有内容，
/// 所以这里只做「挂号」，不做查询断言。
///
/// 卡牌 / 遗物 / 能力 / 角色都靠 [Pool] 特性和 ScriptManagerBridge 注册，
/// 不需要在这里手动 AddModelToPool。
/// </summary>
[ModInitializer(nameof(Initialize))]
public static class Entry
{
    /// <summary>必须和 Emberkeeper.json 里的 id、以及资源文件夹名完全一致。</summary>
    public const string ModId = "Emberkeeper";

    public static void Initialize()
    {
        try
        {
            // 让 Godot 扫描本程序集里的 C# 脚本（自定义内容靠它注册）
            ScriptManagerBridge.LookupScriptsInAssembly(Assembly.GetExecutingAssembly());

            Log.Info($"[{ModId}] 守烬人已加载。");
            Log.Info($"[{ModId}] 角色 ID 应为 EMBERKEEPER-EMBERKEEPER_CHARACTER；"
                   + "在控制台执行 dump 可核对实际注册结果。");
        }
        catch (Exception ex)
        {
            // 初始化失败不该拖垮整个游戏，但一定要把原因写进日志
            Log.Error($"[{ModId}] 初始化失败: {ex}");
        }
    }
}
