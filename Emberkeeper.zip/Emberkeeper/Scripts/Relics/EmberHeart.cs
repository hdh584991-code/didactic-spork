using System.Collections.Generic;
using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.Models;
using Emberkeeper.Scripts.Characters.Pools;
using Emberkeeper.Scripts.Powers;

namespace Emberkeeper.Scripts.Relics;

/// <summary>
/// 余烬心核 —— 守烬人的起始遗物。
/// 每回合开始时，获得 1 层余烬。
///
/// 教程「03 - 添加新遗物」：继承 CustomRelicModel，用 [Pool] 指定遗物池。
/// 图标路径按教程写法用 Id.Entry 的小写，即
///   EMBERKEEPER-EMBER_HEART → res://Emberkeeper/images/relics/ember_heart.png
/// </summary>
[Pool(typeof(EmberRelicPool))]
public class EmberHeart : CustomRelicModel
{
    public override RelicRarity Rarity => RelicRarity.Starter;

    // 小图标（原版 85x85）
    public override string PackedIconPath => $"res://Emberkeeper/images/relics/{Id.Entry.ToLowerInvariant()}.png";

    // 轮廓图标（原版 85x85）
    protected override string PackedIconOutlinePath => $"res://Emberkeeper/images/relics/{Id.Entry.ToLowerInvariant()}_outline.png";

    // 大图标（原版 256x256）
    public override string BigIconPath => $"res://Emberkeeper/images/relics/{Id.Entry.ToLowerInvariant()}.png";

    // 每回合开始时给 1 层余烬
    protected override IEnumerable<DynamicVar> CanonicalVars => [];

    public override async Task AfterPlayerTurnStart(PlayerChoiceContext choiceContext, Player player)
    {
        await PowerCmd.Apply<EmberPower>(choiceContext, [player.Creature], 1, player.Creature, null);
    }
}
