using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Models;

namespace Emberkeeper.Scripts.Powers;

/// <summary>
/// 余烬（Ember）—— 守烬人的核心状态。
///
/// 设计意图：回合开始时，身上的余烬全部燃尽，等量转化为格挡。
/// 于是「这回合打得越凶 → 攒的余烬越多 → 下回合开局越耐打」。
///
/// ⚠️ 当前状态：回合开始的转化钩子**尚未接上**。
/// 原因是 BaseLib 各版本的钩子名与签名不一致，凭猜测写会编译失败。
/// 构建流程里的「探测 API」步骤会打印 PowerModel / CustomPowerModel 的
/// 全部可重写方法，拿到真实名字后再补这一段。
/// 目前余烬可以正常叠层、显示图标和文本，只是不会自动转成格挡。
///
/// 教程「05 - 添加新能力」：继承 CustomPowerModel，图标用
/// CustomPackedIconPath / CustomBigIconPath。
/// </summary>
public class EmberPower : CustomPowerModel
{
    // 增益
    public override PowerType Type => PowerType.Buff;

    // 可叠加（层数就是余烬数量）
    public override PowerStackType StackType => PowerStackType.Counter;

    // 小图标（游戏内显示约 64x64）
    public override string? CustomPackedIconPath => "res://Emberkeeper/images/powers/ember_power.png";

    // 大图标（悬停详情，256x256）
    public override string? CustomBigIconPath => "res://Emberkeeper/images/powers/ember_power.png";

    // TODO: 拿到真实钩子名后补上「回合开始 → 余烬转格挡」
    // 预期形态（签名以探测结果为准）：
    //
    // public override async Task AfterPlayerTurnStart(PlayerChoiceContext choiceContext, Player player)
    // {
    //     int amount = Amount;
    //     if (amount <= 0) return;
    //     await CreatureCmd.GainBlock(Owner, amount, ...);
    //     await PowerCmd.Remove<EmberPower>(Owner, amount);
    // }
}
