using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Models;

namespace Emberkeeper.Scripts.Cards;

/// <summary>
/// 守烬人所有卡牌的抽象基类。
///
/// 按教程「01 - 添加卡牌」的建议：用一个 abstract 类统一指定卡图路径，
/// 避免每张卡都写一遍。卡图路径为
///   res://Emberkeeper/images/cards/{类名}.png
/// 例如 EmberStrike → res://Emberkeeper/images/cards/EmberStrike.png
///
/// 继承 CustomCardModel（BaseLib），而不是原版 CardModel。
/// </summary>
public abstract class EmberCardModel : CustomCardModel
{
    public override string PortraitPath => $"res://Emberkeeper/images/cards/{GetType().Name}.png";

    protected EmberCardModel(
        int energyCost,
        CardType type,
        CardRarity rarity,
        TargetType targetType,
        bool shouldShowInCardLibrary)
        : base(energyCost, type, rarity, targetType, shouldShowInCardLibrary)
    {
    }
}
