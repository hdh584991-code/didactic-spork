using System.Collections.Generic;
using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.ValueProps;
using Emberkeeper.Scripts.Characters.Pools;
using Emberkeeper.Scripts.Powers;

namespace Emberkeeper.Scripts.Cards;

/// <summary>
/// 守烬 —— 守烬人的基础防御牌（起始卡组 5 张）。
/// 获得 5 点格挡，获得 2 层余烬。升级后获得 8 点格挡。
/// </summary>
[Pool(typeof(EmberCardPool))]
public class EmberDefend : EmberCardModel
{
    private const int energyCost = 1;
    private const CardType type = CardType.Skill;
    private const CardRarity rarity = CardRarity.Common;
    private const TargetType targetType = TargetType.Self;
    private const bool shouldShowInCardLibrary = true;

    // 教程提示：防御牌需要 Defend tag
    public override IEnumerable<CardTag> Tags => [CardTag.Defend];

    // 教程提示：防御牌需要 GainsBlock = true，否则相关效果识别不到
    public override bool GainsBlock => true;

    // 攒多少层余烬
    private const int EmberGain = 2;

    protected override IEnumerable<DynamicVar> CanonicalVars =>
    [
        new BlockVar(5, ValueProp.Move),
    ];

    public EmberDefend() : base(energyCost, type, rarity, targetType, shouldShowInCardLibrary)
    {
    }

    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        // 1) 获得格挡
        await CreatureCmd.GainBlock(Owner.Creature, DynamicVars.Block, cardPlay, false);

        // 2) 获得余烬
        await PowerCmd.Apply<EmberPower>(choiceContext, [Owner.Creature], EmberGain, Owner.Creature, this);
    }

    protected override void OnUpgrade()
    {
        DynamicVars.Block.UpgradeValueBy(3); // 5 → 8
    }
}
