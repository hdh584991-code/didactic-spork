using System.Collections.Generic;
using System.Threading.Tasks;
using BaseLib.Abstracts;
using BaseLib.Utils;   // PoolAttribute 在 BaseLib.Utils
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.ValueProps;
using Emberkeeper.Scripts.Characters.Pools;
using Emberkeeper.Scripts.Powers;

namespace Emberkeeper.Scripts.Cards;

/// <summary>
/// 燃烬 —— 守烬人的专属起始牌（起始卡组 1 张）。
///
/// 定位：一张牌同时给伤害、格挡、余烬，用来教会玩家循环：
///   打出 → 攒余烬 → 下回合开局余烬转成护甲。
///
/// 造成 8 点伤害，获得 3 点格挡，获得 1 层余烬。
/// 升级后：11 点伤害、4 点格挡、2 层余烬。
/// </summary>
[Pool(typeof(EmberCardPool))]
public class EmberBurst : EmberCardModel
{
    private const int energyCost = 1;
    private const CardType type = CardType.Attack;
    private const CardRarity rarity = CardRarity.Common;
    private const TargetType targetType = TargetType.AnyEnemy;
    private const bool shouldShowInCardLibrary = true;

    private const int EmberGain = 1;

    protected override IEnumerable<DynamicVar> CanonicalVars =>
    [
        new DamageVar(8, ValueProp.Move),
        new BlockVar(3, ValueProp.Move),
    ];

    public EmberBurst() : base(energyCost, type, rarity, targetType, shouldShowInCardLibrary)
    {
    }

    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        // 1) 先拿格挡
        await CreatureCmd.GainBlock(Owner.Creature, DynamicVars.Block, cardPlay, false);

        // 2) 造成伤害
        await DamageCmd.Attack(DynamicVars.Damage.BaseValue)
            .FromCard(this, cardPlay)
            .Targeting(cardPlay.Target)
            .Execute(choiceContext);

        // 3) 攒余烬（升级后多给 1 层）
        await PowerCmd.Apply<EmberPower>(choiceContext, [Owner.Creature], CurrentEmberGain, Owner.Creature, this);
    }

    protected override void OnUpgrade()
    {
        DynamicVars.Damage.UpgradeValueBy(3); // 8  → 11
        DynamicVars.Block.UpgradeValueBy(1);  // 3  → 4
    }

    /// <summary>当前应给的余烬层数：升级后从 1 层变 2 层。</summary>
    private int CurrentEmberGain => IsUpgraded ? EmberGain + 1 : EmberGain;
}
