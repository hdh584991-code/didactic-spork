using System.Collections.Generic;
using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.ValueProps;
using Emberkeeper.Scripts.Characters.Pools;
using Emberkeeper.Scripts.Powers;

namespace Emberkeeper.Scripts.Cards;

/// <summary>
/// 薪击 —— 守烬人的基础攻击牌（起始卡组 5 张）。
/// 造成 6 点伤害，获得 1 层余烬。升级后造成 9 点伤害。
/// </summary>
[Pool(typeof(EmberCardPool))]
public class EmberStrike : EmberCardModel
{
    private const int energyCost = 1;
    private const CardType type = CardType.Attack;
    private const CardRarity rarity = CardRarity.Common;
    private const TargetType targetType = TargetType.AnyEnemy;
    private const bool shouldShowInCardLibrary = true;

    // 基础攻击牌的 tag，教程提示必须加
    public override IEnumerable<CardTag> Tags => [CardTag.Strike];

    // 攒多少层余烬
    private const int EmberGain = 1;

    protected override IEnumerable<DynamicVar> CanonicalVars =>
    [
        new DamageVar(6, ValueProp.Move),
    ];

    public EmberStrike() : base(energyCost, type, rarity, targetType, shouldShowInCardLibrary)
    {
    }

    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        // 1) 造成伤害
        await DamageCmd.Attack(DynamicVars.Damage.BaseValue)
            .FromCard(this, cardPlay)
            .Targeting(cardPlay.Target)
            .Execute(choiceContext);

        // 2) 获得余烬
        await PowerCmd.Apply<EmberPower>(choiceContext, [Owner.Creature], EmberGain, Owner.Creature, this);
    }

    protected override void OnUpgrade()
    {
        DynamicVars.Damage.UpgradeValueBy(3); // 6 → 9
    }
}
