using Godot;
using BaseLib.Abstracts;

namespace Emberkeeper.Scripts.Characters.Pools;

/// <summary>
/// 守烬人的卡池。
/// 教程「14 - 添加新人物」：人物独有的卡池、遗物池、药水池各一个。
/// Title 是卡池 ID，必须唯一防撞车。
/// </summary>
public class EmberCardPool : CustomCardPoolModel
{
    // 卡池 ID
    public override string Title => "emberkeeper";

    // 描述中使用的能量图标（24x24）
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";

    // tooltip 和卡牌左上角的能量图标（74x74）
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";

    // 卡池主题色（暗橙）
    public override Color DeckEntryCardColor => new(0.85f, 0.35f, 0.12f);

    // 使用原版卡框时，用这个颜色改卡框色调
    public override Color ShaderColor => new(0.85f, 0.35f, 0.12f);

    // 不是无色池
    public override bool IsColorless => false;
}

/// <summary>
/// 守烬人的遗物池。
/// </summary>
public class EmberRelicPool : CustomRelicPoolModel
{
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
}

/// <summary>
/// 守烬人的药水池。
/// </summary>
public class EmberPotionPool : CustomPotionPoolModel
{
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
}
