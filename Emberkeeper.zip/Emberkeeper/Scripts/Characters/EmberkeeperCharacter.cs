using System.Collections.Generic;
using Godot;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Characters;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.PotionPools;
using MegaCrit.Sts2.Core.Models.RelicPools;
using Emberkeeper.Scripts.Cards;
using Emberkeeper.Scripts.Characters.Pools;
using Emberkeeper.Scripts.Relics;

namespace Emberkeeper.Scripts.Characters;

/// <summary>
/// 新可玩角色：守烬人（Emberkeeper）
///
/// 核心机制 —— 余烬（Ember）：
///   回合开始时，身上的余烬会全部燃尽，等量转化为格挡；
///   攻击牌在造成伤害的同时积攒余烬，所以「打得越狠，下回合越耐打」。
///
/// 教程「14 - 添加新人物」明确建议：
///   继承 PlaceholderCharacterModel（不是 CustomCharacterModel），
///   你没有的资源直接注释掉以使用原版。
///
/// 【美术方案】
///   PlaceholderID = "silent"：场景类资源（战斗模型、能量盘、选人背景、
///   商店/篝火）全部沿用静默猎手，游戏本体自带，100% 能加载。
///   只有「纯图片」类的选人立绘 / 未解锁立绘 / 左上角头像可以用我们自己的图，
///   由 UseCustomImages 控制；一旦 pck 没打进包，把它改回 false 即可恢复。
/// </summary>
public class EmberkeeperCharacter : PlaceholderCharacterModel
{
    // ══════════════════════════════════════════════════════════
    // 是否使用我们自己的贴图
    //
    //   true  = 用 res://Emberkeeper/images/ 下自己的图
    //   false = 全部沿用 silent 的原版图
    //
    // ⚠️ 只有当 pck 真的打进包里时 true 才有意义。
    //    构建脚本会在 pck 导出失败时自动把它改成 false，保持产物自洽。
    // ══════════════════════════════════════════════════════════
    public const bool UseCustomImages = true;

    /// <summary>
    /// 借用哪个原版角色的全套美术：ironclad / silent / defect / regent / necrobinder。
    /// </summary>
    public override string PlaceholderID => "silent";

    // ── 颜色（教程列出的三项）──
    public override Color NameColor => new(0.85f, 0.35f, 0.12f);
    public override Color EnergyLabelOutlineColor => new(0.35f, 0.08f, 0.02f);
    public override Color MapDrawingColor => new(0.85f, 0.35f, 0.12f);

    // 性别：影响部分动态文本
    public override CharacterGender Gender => CharacterGender.Neutral;

    // 初始血量
    public override int StartingHp => 75;

    // 初始金币
    public override int StartingGold => 99;

    // ── 场景类资源：全部不覆写，沿用 silent ──
    // CustomVisualPath / CustomEnergyCounterPath / CustomCharacterSelectBg /
    // CustomRestSiteAnimPath / CustomMerchantAnimPath / CustomTrailPath
    // 教程：没有的资源直接注释掉以使用原版。

    // ── 贴图类资源 ──

    // 左上角小头像（保存的 run 信息弹窗里也用）
    public override string? CustomIconTexturePath
        => UseCustomImages ? "res://Emberkeeper/images/char_select_emberkeeper.png" : base.CustomIconTexturePath;

    // 角色选择界面大图
    public override string? CustomCharacterSelectIconPath
        => UseCustomImages ? "res://Emberkeeper/images/char_select_emberkeeper.png" : base.CustomCharacterSelectIconPath;

    // 角色选择界面大图（锁定态）
    public override string? CustomCharacterSelectLockedIconPath
        => UseCustomImages ? "res://Emberkeeper/images/char_select_emberkeeper_locked.png" : base.CustomCharacterSelectLockedIconPath;

    // ── 三个池子 ──
    public override CardPoolModel CardPool => ModelDb.CardPool<EmberCardPool>();
    public override RelicPoolModel RelicPool => ModelDb.RelicPool<EmberRelicPool>();
    public override PotionPoolModel PotionPool => ModelDb.PotionPool<EmberPotionPool>();

    // ── 起始卡组：5 薪击 + 5 守烬 + 1 燃烬 ──
    public override IEnumerable<CardModel> StartingDeck =>
    [
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),

        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),

        ModelDb.Card<EmberBurst>(),
    ];

    // ── 起始遗物 ──
    public override IReadOnlyList<RelicModel> StartingRelics =>
    [
        ModelDb.Relic<EmberHeart>(),
    ];

    // 教程：攻击建筑师的特效列表，照抄原版即可
    public override List<string> GetArchitectAttackVfx() =>
    [
        "vfx/vfx_attack_blunt",
        "vfx/vfx_heavy_blunt",
        "vfx/vfx_attack_slash",
        "vfx/vfx_bloody_impact",
        "vfx/vfx_rock_shatter"
    ];
}
