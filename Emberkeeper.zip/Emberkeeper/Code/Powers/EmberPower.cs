using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Powers;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.ValueProps;

namespace Emberkeeper.Code.Powers;

/// <summary>
/// 余烬（Ember）—— 守烬人的核心资源状态。
///
/// 规则：自己回合开始时，身上的余烬全部燃尽，等量转化为格挡。
/// 也就是说：这一回合打得越凶，攒的余烬越多，下回合开局就越耐打。
/// </summary>
public class EmberPower : CustomPowerModel
{
    // 增益
    public override PowerType Type => PowerType.Buff;

    // 可叠加（Counter）
    public override PowerStackType StackType => PowerStackType.Counter;

    // 图标：小图 64x64，大图 256x256，1:1 即可
#if !EMBERKEEPER_NO_PCK
    public override string? CustomPackedIconPath => "res://Emberkeeper/images/powers/ember.png";
    public override string? CustomBigIconPath => "res://Emberkeeper/images/powers/ember.png";
#endif

    // ⚠️ 回合开始钩子暂时注释掉：不同 sts2 版本里 PowerModel 的钩子名/签名不一致，
    // 直接 override 会编译失败。CI 里的「探测 PowerModel 钩子」步骤会打印出真实签名，
    // 拿到后把下面这段的解开、改对方法名即可。
    //
    // public override async Task AfterTurnStart(PlayerChoiceContext choiceContext, Creature creature)
    // {
    //     if (creature != Owner) return;
    //     int amount = Amount;
    //     if (amount <= 0) return;
    //     await CreatureCmd.GainBlock(Owner, amount, ValueProp.Move, null);
    //     await PowerCmd.Remove(this);
    // }
}
