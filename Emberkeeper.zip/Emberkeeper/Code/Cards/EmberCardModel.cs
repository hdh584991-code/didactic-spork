using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Entities.Cards;

namespace Emberkeeper.Code.Cards;

/// <summary>
/// 守烬人所有卡牌的基类：统一把卡图指到 images/cards/{类名}.png。
///
/// 属性名是 BaseLib 的 CustomPortraitPath（不是 PortraitPath）：
/// BaseLib 内部会 patch CardModel.PortraitPath / Portrait / PortraitPngPath
/// 三个 getter，优先读 CustomPortraitPath。
/// </summary>
public abstract class EmberCardModel : CustomCardModel
{
#if !EMBERKEEPER_NO_PCK
    public override string? CustomPortraitPath => $"res://Emberkeeper/images/cards/{GetType().Name}.png";
#endif

    protected EmberCardModel(
        int energyCost,
        CardType type,
        CardRarity rarity,
        TargetType targetType,
        bool shouldShowInLibrary)
        : base(energyCost, type, rarity, targetType, shouldShowInLibrary)
    {
    }
}
