using System.Collections.Generic;
using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.ValueProps;
using Emberkeeper.Code.Characters.Pools;
using Emberkeeper.Code.Powers;

namespace Emberkeeper.Code.Cards;

/// <summary>
/// 守烬 —— 起始防御牌。
/// 获得 5（升级 8）点格挡，并获得 2 层余烬（下回合开局会烧成格挡）。
/// </summary>
[Pool(typeof(EmberCardPool))]
public class EmberDefend : EmberCardModel
{
    private const int EnergyCost = 1;
    private const CardType Type = CardType.Skill;
    private const CardRarity Rarity = CardRarity.Common;
    private const TargetType Target = TargetType.Self;
    private const bool ShowInLibrary = true;

    private const int EmberGain = 2;

    protected override IEnumerable<DynamicVar> CanonicalVars => [new BlockVar(5, ValueProp.Move)];

    // 防御牌必须写这个，否则「巩固」之类按格挡识别的牌认不出它
    public override bool GainsBlock => true;

    public override IEnumerable<CardTag> Tags => [CardTag.Defend];

    public EmberDefend() : base(EnergyCost, Type, Rarity, Target, ShowInLibrary)
    {
    }

    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        await CreatureCmd.GainBlock(Owner.Creature, DynamicVars.Block.BaseValue, ValueProp.Move, cardPlay);

        await PowerCmd.Apply<EmberPower>(choiceContext, Owner.Creature, EmberGain, Owner.Creature, cardPlay);
    }

    protected override void OnUpgrade()
    {
        DynamicVars.Block.UpgradeValueBy(3); // 5 → 8
    }
}
