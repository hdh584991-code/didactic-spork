using System.Collections.Generic;
using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.ValueProps;
using Emberkeeper.Code.Powers;

namespace Emberkeeper.Code.Cards;

/// <summary>
/// 燃烬 —— 守烬人的专属起始牌（起始卡组里只有 1 张）。
///
/// 定位：一张「攻守兼备」的起手牌，一次性把伤害、格挡、余烬三样都给你，
/// 用来教会玩家这个角色的循环：打出去 → 攒余烬 → 下回合开局自动变成护甲。
///
/// 造成 8 点伤害，获得 3 点格挡，获得 1 层余烬。
/// 升级后：造成 11 点伤害，获得 4 点格挡，获得 2 层余烬。
/// </summary>
public class EmberBurst : EmberCardModel
{
    private const int energyCost = 1;
    private const CardType type = CardType.Attack;
    private const CardRarity rarity = CardRarity.Common;
    private const TargetType target = TargetType.AnyEnemy;
    private const bool ShowInLibrary = true;

    // 攒多少层余烬（升级后 +1）
    private const int EmberGain = 1;

    // 同时带伤害和格挡两个动态变量
    protected override IEnumerable<DynamicVar> CanonicalVars =>
    [
        new DamageVar(8, ValueProp.Move),
        new BlockVar(3, ValueProp.Move),
    ];

    public EmberBurst() : base(energyCost, type, rarity, target, ShowInLibrary)
    {
    }

    /// <summary>内联本地化：不依赖 pck 里的 json，保证卡名一定显示正确。</summary>
    public override List<(string, string)>? Localization =>
    [
        ("title", "燃烬"),
        ("description", "获得{Block:diff()}点格挡。造成{Damage:diff()}点伤害。获得 [gold]余烬[/gold]1 层（升级后 2 层）。"),
    ];

    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        // 1) 先给自己加格挡（写在伤害前面，避免被打断时漏掉）
        await CreatureCmd.GainBlock(Owner.Creature, DynamicVars.Block.BaseValue, ValueProp.Move, this);

        // 2) 造成伤害
        await DamageCmd.Attack(DynamicVars.Damage.BaseValue)
            .FromCard(this, cardPlay)
            .Targeting(cardPlay.Target)
            .Execute(choiceContext);

        // 3) 攒余烬（升级后多给 1 层）
        await PowerCmd.Apply<EmberPower>(choiceContext, [Owner.Creature], CurrentEmberGain, Owner.Creature, this);
    }

    protected override void OnUpgrade()
    {
        DynamicVars.Damage.UpgradeValueBy(3);   // 8  → 11
        DynamicVars.Block.UpgradeValueBy(1);    // 3  → 4
    }

    /// <summary>
    /// 当前应给的余烬层数：升级后从 1 层变 2 层。
    /// </summary>
    private int CurrentEmberGain => IsUpgraded ? EmberGain + 1 : EmberGain;
}
