using System.Collections.Generic;
using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Localization.DynamicVars;
using MegaCrit.Sts2.Core.ValueProps;
using Emberkeeper.Code.Characters.Pools;
using Emberkeeper.Code.Powers;

namespace Emberkeeper.Code.Cards;

/// <summary>
/// 薪击 —— 起始攻击牌。
/// 造成 6（升级 9）点伤害，并获得 1 层余烬。
/// </summary>
[Pool(typeof(EmberCardPool))]
public class EmberStrike : EmberCardModel
{
    private const int energyCost = 1;
    private const CardType type = CardType.Attack;
    private const CardRarity rarity = CardRarity.Common;
    private const TargetType target = TargetType.AnyEnemy;
    private const bool ShowInLibrary = true;

    // 打一张攒多少层余烬
    private const int EmberGain = 1;

    protected override IEnumerable<DynamicVar> CanonicalVars => [new DamageVar(6, ValueProp.Move)];

    // 标记为「打击」，这样「剑柄打击」之类的联动牌认得出它
    public override IEnumerable<CardTag> Tags => [CardTag.Strike];

    public EmberStrike() : base(energyCost, type, rarity, target, ShowInLibrary)
    {
    }

    protected override async Task OnPlay(PlayerChoiceContext choiceContext, CardPlay cardPlay)
    {
        // 造成伤害
        await DamageCmd.Attack(DynamicVars.Damage.BaseValue)
            .FromCard(this, cardPlay)
            .Targeting(cardPlay.Target)
            .Execute(choiceContext);

        // 攒余烬
        await PowerCmd.Apply<EmberPower>(choiceContext, Owner.Creature, EmberGain, Owner.Creature, cardPlay);
    }

    protected override void OnUpgrade()
    {
        DynamicVars.Damage.UpgradeValueBy(3); // 6 → 9
    }
}
