using System.Threading.Tasks;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.Entities.Relics;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using Emberkeeper.Code.Powers;

namespace Emberkeeper.Code.Relics;

/// <summary>
/// 余烬心核 —— 守烬人的起始遗物。
/// 每个自己的回合开始时，获得 1 层余烬（保证每回合都有一点点灰烬护甲进账）。
/// </summary>
public class EmberHeart : CustomRelicModel
{
    public override RelicRarity Rarity => RelicRarity.Starter;

    // 图标：小图 / 描边图 85x85，大图 256x256
#if !EMBERKEEPER_NO_PCK
    public override string PackedIconPath => "res://Emberkeeper/images/relics/emberheart.png";
    protected override string PackedIconOutlinePath => "res://Emberkeeper/images/relics/emberheart_outline.png";
    protected override string BigIconPath => "res://Emberkeeper/images/relics/emberheart.png";
#endif

    public override async Task AfterPlayerTurnStart(PlayerChoiceContext choiceContext, Player player)
    {
        await PowerCmd.Apply<EmberPower>(choiceContext, [Owner.Creature], 1, Owner.Creature, null);
    }

    // 想给「欧洛巴斯之触」做升级版，就再写一个遗物类然后在这里返回：
    // public override RelicModel? GetUpgradeReplacement() => ModelDb.Relic<EmberHeartUpgraded>();
}
