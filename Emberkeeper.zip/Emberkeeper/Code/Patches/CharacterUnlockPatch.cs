using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.Characters;
using MegaCrit.Sts2.Core.Unlocks;
using Emberkeeper.Code.Characters;

namespace Emberkeeper.Code.Patches;

/// <summary>
/// 保证守烬人在选人界面处于「已解锁」状态。
///
/// 背景（来自 0.111.0 反编译源码 NCharacterSelectButton）：
///   _isLocked = !unlockState.Characters.Contains(_character);
/// 而 UnlockState.Characters 是从 ModelDb.AllCharacters 出发、只减去原版角色得到的。
/// 自定义角色如果没被算进这个集合，按钮就会是锁定的：
/// 点击没反应、图标空白、界面继续显示上一个角色的信息。
///
/// 这里做一个防御性补丁：如果集合里没有守烬人，就补进去。
/// 已经在里面的话什么都不做（不会重复添加）。
/// </summary>
[HarmonyPatch(typeof(UnlockState), nameof(UnlockState.Characters), MethodType.Getter)]
internal static class CharacterUnlockPatch
{
    private static IEnumerable<CharacterModel> Postfix(IEnumerable<CharacterModel> __result)
    {
        var list = __result.ToList();
        try
        {
            var mine = ModelDb.AllCharacters.FirstOrDefault(c => c is EmberkeeperCharacter);
            if (mine == null)
            {
                return list;
            }

            if (!list.Contains(mine))
            {
                list.Add(mine);
                Log.Info("[Emberkeeper] 守烬人未被解锁，已补进 UnlockState.Characters。");
            }
        }
        catch (Exception ex)
        {
            // 解锁判定不该拖垮游戏，但要把原因写进日志
            Log.Error($"[Emberkeeper] 解锁补丁失败: {ex}");
        }

        return list;
    }
}
