using System.Collections.Generic;
using Godot;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Characters;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.PotionPools;
using MegaCrit.Sts2.Core.Models.RelicPools;
using Emberkeeper.Code.Cards;
using Emberkeeper.Code.Characters.Pools;
using Emberkeeper.Code.Relics;

namespace Emberkeeper.Code.Characters;

/// <summary>
/// 新可玩角色：守烬人（Emberkeeper）
///
/// 核心机制 —— 余烬（Ember）：
///   回合开始时，身上的余烬会全部燃尽，等量转化为格挡；
///   攻击牌在造成伤害的同时积攒余烬，所以"打得越狠，下回合越耐打"。
///
/// 【当前美术方案】
///   继承 PlaceholderCharacterModel，PlaceholderID = "silent"，
///   也就是全套借用静默猎手的立绘 / 音效 / 动画。
///   等你自己画好贴图后，把下面 UseCustomArt 改成 true 即可切回自定义资源。
/// </summary>
public class EmberkeeperCharacter : PlaceholderCharacterModel
{
    // ══════════════════════════════════════════════════════════
    // 美术开关
    //
    //   false（现在）：全部借用静默猎手（silent）的立绘 / 音效 / 动画
    //   true （以后）：使用 Emberkeeper/images、Emberkeeper/scenes 下你自己的资源
    //
    // 切换方法：把下面的 false 改成 true，然后重新编译 + 导出 pck 即可，
    // 不用改别的地方。
    // ══════════════════════════════════════════════════════════
    public const bool UseCustomArt = true;

    // ────────────────────────── 基础设定 ──────────────────────────

    /// <summary>
    /// 借用哪个原版角色的全套美术。
    /// 可选：ironclad / silent / defect / regent / necrobinder
    /// 现在用静默猎手（silent）。
    /// </summary>
    public override string PlaceholderID => "silent";

    // 角色名颜色（暗橙）
    public override Color NameColor => new(0.85f, 0.35f, 0.12f);

    // 能量图标描边颜色
    public override Color EnergyLabelOutlineColor => new(0.35f, 0.08f, 0.02f);

    // 地图上画画用的颜色
    public override Color MapDrawingColor => new(0.85f, 0.35f, 0.12f);

    // 性别：影响部分动态文本（他/她/它）
    public override CharacterGender Gender => CharacterGender.Neutral;

    // 初始血量
    public override int StartingHp => 75;

    // 初始金币
    public override int StartingGold => 99;

    // ────────────────────────── 自定义美术（暂时关闭） ──────────────────────────
    //
    // UseCustomArt = false 时这一段不参与编译，
    // 角色会完整使用 PlaceholderID（silent）的立绘、能量盘、选人图、背景、商店/篝火动画。
    //
    // 等你准备好了贴图，把 UseCustomArt 改成 true，并把文件放到：
    //   Emberkeeper/images/char_select_emberkeeper.png          选人界面立绘
    //   Emberkeeper/images/char_select_emberkeeper_locked.png   未解锁立绘
    //   Emberkeeper/images/character_placeholder.png            战斗/商店/篝火立绘
    //   Emberkeeper/scenes/emberkeeper_character.tscn           战斗角色场景
    //   Emberkeeper/scenes/emberkeeper_energy_counter.tscn      能量表盘
    //   Emberkeeper/scenes/emberkeeper_bg.tscn                  选人界面背景
    //   Emberkeeper/scenes/emberkeeper_merchant.tscn            商店立绘
    //   Emberkeeper/scenes/emberkeeper_rest_site.tscn           篝火立绘

    // 战斗中的人物场景
    public override string CustomVisualPath
        => UseCustomArt ? "res://Emberkeeper/scenes/emberkeeper_character.tscn" : base.CustomVisualPath;

    // 能量表盘
    public override string CustomEnergyCounterPath
        => UseCustomArt ? "res://Emberkeeper/scenes/emberkeeper_energy_counter.tscn" : base.CustomEnergyCounterPath;

    // 左上角小头像
    public override string? CustomIconTexturePath
        => UseCustomArt ? "res://Emberkeeper/images/char_select_emberkeeper.png" : base.CustomIconTexturePath;

    // 角色选择界面大图 / 锁定态
    public override string? CustomCharacterSelectIconPath
        => UseCustomArt ? "res://Emberkeeper/images/char_select_emberkeeper.png" : base.CustomCharacterSelectIconPath;

    public override string? CustomCharacterSelectLockedIconPath
        => UseCustomArt ? "res://Emberkeeper/images/char_select_emberkeeper_locked.png" : base.CustomCharacterSelectLockedIconPath;

    // 角色选择界面背景
    public override string? CustomCharacterSelectBg
        => UseCustomArt ? "res://Emberkeeper/scenes/emberkeeper_bg.tscn" : base.CustomCharacterSelectBg;

    // 商店 / 篝火立绘
    public override string CustomMerchantAnimPath
        => UseCustomArt ? "res://Emberkeeper/scenes/emberkeeper_merchant.tscn" : base.CustomMerchantAnimPath;

    public override string CustomRestSiteAnimPath
        => UseCustomArt ? "res://Emberkeeper/scenes/emberkeeper_rest_site.tscn" : base.CustomRestSiteAnimPath;

    // ────────────────────────── 本地化（内联，最可靠） ──────────────────────────
    //
    // 之前名字/介绍显示成别的角色，是因为 pck 里的 json 没被正确读到。
    // 这里改用 BaseLib 提供的内联本地化接口：直接在代码里给出文本，
    // 不依赖任何外部 json 文件和 key 拼接规则，100% 一定会生效。
    //
    // 格式是 (key后缀, 文本)。BaseLib 会自动套上本角色的 ID 前缀。

    public override List<(string, string)>? Localization =>
    [
        ("title", "守烬人"),
        ("titleObject", "守烬人"),
        ("description",
            "塔火熄灭之后仍未离开的人。\n" +
            "他把尚未燃尽的[gold]余烬[/gold]收进胸腔，让它们在下一个清晨替自己挡下第一击。\n\n" +
            "[gold]初始生命[/gold]：75\n" +
            "[gold]初始金币[/gold]：99\n" +
            "[gold]起始卡组[/gold]：5 张薪击、5 张守烬、1 张燃烬\n\n" +
            "[blue]余烬[/blue]：回合开始时全部燃尽，等量转化为格挡。"),
        ("unlockText", "用[pink]{Prerequisite}[/pink]进行一局游戏来解锁这个角色。"),
        ("cardsModifierTitle", "守烬人卡牌"),
        ("cardsModifierDescription", "守烬人的卡牌现在会出现在奖励和商店中。"),
        ("possessiveAdjective", "他的"),
        ("pronounSubject", "他"),
        ("pronounObject", "他"),
        ("pronounPossessive", "他的"),
        ("aromaPrinciple", "[sine][blue]……还烧着……[/blue][/sine]"),
        ("goldMonologue", "[sine]金币也会凉。我先替它们保管一会儿。[/sine]"),
        ("eventDeathPrevention", "火还没灭。我还不能倒。"),
        ("banter.alive.endTurnPing", "……留一点火星给你。"),
        ("banter.dead.endTurnPing", "……替我把火看好。"),
    ];

    // ────────────────────────── 池子绑定 ──────────────────────────

    public override CardPoolModel CardPool => ModelDb.CardPool<EmberCardPool>();
    public override RelicPoolModel RelicPool => ModelDb.RelicPool<EmberRelicPool>();
    public override PotionPoolModel PotionPool => ModelDb.PotionPool<EmberPotionPool>();

    // ────────────────────────── 初始卡组 ──────────────────────────
    // 5 张基础攻击（薪击）+ 5 张基础防御（守烬）+ 1 张角色专属牌（燃烬），共 11 张。

    public override IEnumerable<CardModel> StartingDeck =>
    [
        // 基础攻击 ×5
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberStrike>(),

        // 基础防御 ×5
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),
        ModelDb.Card<EmberDefend>(),

        // 角色专属起始牌 ×1
        ModelDb.Card<EmberBurst>(),
    ];

    // ────────────────────────── 初始遗物 ──────────────────────────

    public override IReadOnlyList<RelicModel> StartingRelics =>
    [
        ModelDb.Relic<EmberHeart>(),
    ];

    // ────────────────────────── 其它 ──────────────────────────

    // 攻击建筑师（Boss）时的打击特效列表
    public override List<string> GetArchitectAttackVfx() =>
    [
        "vfx/vfx_attack_blunt",
        "vfx/vfx_heavy_blunt",
        "vfx/vfx_attack_slash",
        "vfx/vfx_bloody_impact",
        "vfx/vfx_rock_shatter"
    ];
}
