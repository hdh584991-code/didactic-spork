using Godot;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.RelicPools;
using MegaCrit.Sts2.Core.Models.PotionPools;
using Emberkeeper.Code.Cards;
using Emberkeeper.Code.Relics;

namespace Emberkeeper.Code.Characters.Pools;

/// <summary>
/// 守烬人的专属卡池。
///
/// 说明：BaseLib 的 CustomCardModel 在构造时就会自动注册自己，
/// 但「属于哪个池」由 GenerateAllCards() 决定，所以这里显式列出本池的卡，
/// 不依赖任何 [Pool] 特性（该特性在部分 BaseLib 版本里已移除）。
/// 你以后加新卡，记得也加进这个数组。
/// </summary>
public class EmberCardPool : CustomCardPoolModel
{
#if !EMBERKEEPER_NO_PCK
    // 描述文字里用的小能量图标（24x24）
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";

    // tooltip 和卡牌左上角的大能量图标（74x74）
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
#endif

    // 卡池主题色（暗橙红：余烬）
    public override Color ShaderColor => new(0.85f, 0.35f, 0.12f);

    /// <summary>本卡池包含的所有卡牌。</summary>
    protected override CardModel[] GenerateAllCards() =>
    [
        ModelDb.Card<EmberStrike>(),
        ModelDb.Card<EmberDefend>(),
    ];
}

/// <summary>
/// 守烬人的专属遗物池。
/// </summary>
public class EmberRelicPool : CustomRelicPoolModel
{
#if !EMBERKEEPER_NO_PCK
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
#endif

    protected override IEnumerable<RelicModel> GenerateAllRelics() =>
    [
        ModelDb.Relic<EmberHeart>(),
    ];
}

/// <summary>
/// 守烬人的专属药水池。暂时没有专属药水，所以是空的。
/// </summary>
public class EmberPotionPool : CustomPotionPoolModel
{
#if !EMBERKEEPER_NO_PCK
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
#endif
}
