using Godot;
using BaseLib.Abstracts;
using MegaCrit.Sts2.Core.Models.CardPools;
using MegaCrit.Sts2.Core.Models.RelicPools;
using MegaCrit.Sts2.Core.Models.PotionPools;

namespace Emberkeeper.Code.Characters.Pools;

/// <summary>
/// 守烬人的专属卡池。
///
/// 注意：BaseLib 的 CustomCardPoolModel 明确说明「如果用的是 CustomCardModel，
/// 不需要重写 GenerateAllCards()，内容会由 ModHelper.ConcatModelsFromMods 自动加入」。
/// 所以这里只实现基类要求的抽象成员，不做额外覆写。
/// </summary>
public class EmberCardPool : CustomCardPoolModel
{
#if !EMBERKEEPER_NO_PCK
    // 描述文字里用的小能量图标（24x24）
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";

    // tooltip 和卡牌左上角的大能量图标（74x74）
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
#endif

    // 基类抽象成员，必须实现
    public override string Title => "emberkeeper";

    // 基类抽象成员，必须实现
    public override Color DeckEntryCardColor => new(0.85f, 0.35f, 0.12f);

    // 基类抽象成员，必须实现
    public override bool IsColorless => false;

    // 卡框着色（暗橙红：余烬）
    public override Color ShaderColor => new(0.85f, 0.35f, 0.12f);
}

/// <summary>
/// 守烬人的专属遗物池。
/// 同样不覆写 GenerateAllRelics()，交给 BaseLib 自动收集。
/// </summary>
public class EmberRelicPool : CustomRelicPoolModel
{
#if !EMBERKEEPER_NO_PCK
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
#endif

    // 角色专属池，不是共享池
    public override bool IsShared => false;
}

/// <summary>
/// 守烬人的专属药水池。暂时没有专属药水。
/// </summary>
public class EmberPotionPool : CustomPotionPoolModel
{
#if !EMBERKEEPER_NO_PCK
    public override string? TextEnergyIconPath => "res://Emberkeeper/images/energy_ember.png";
    public override string? BigEnergyIconPath => "res://Emberkeeper/images/energy_ember_big.png";
#endif

    public override bool IsShared => false;
}
