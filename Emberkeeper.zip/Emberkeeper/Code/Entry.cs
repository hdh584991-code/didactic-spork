using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Godot.Bridge;              // ScriptManagerBridge 在这里，不是 MegaCrit.Sts2.Core.Scripting
using HarmonyLib;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Modding;
using MegaCrit.Sts2.Core.Models;
using Emberkeeper.Code.Characters;

namespace Emberkeeper.Code;

/// <summary>
/// 守烬人 mod 入口。
///
/// 游戏会扫描程序集里带 [ModInitializer] 的类型，并调用参数指定名字的静态初始化方法。
///
/// 重要：初始化运行在 ModelDb.Init 之前，此刻 ModelDb 还没有内容。
/// 所以这里不做查询断言，只做「挂号」；真正的自检推迟到
/// PostInitSelfCheck（由 BaseLib/游戏在初始化完成后触发）。
/// </summary>
[ModInitializer(nameof(Initialize))]
public static class Entry
{
    /// <summary>必须和 Emberkeeper.json 里的 id、以及资源文件夹名完全一致。</summary>
    public const string ModId = "Emberkeeper";

    private static Harmony? _harmony;

    public static void Initialize()
    {
        try
        {
            _harmony = new Harmony("sts2.emberkeeper");
            _harmony.PatchAll(Assembly.GetExecutingAssembly());

            // 让 Godot 扫描本程序集里的 C# 脚本（卡牌 / 遗物 / 能力 / 角色都靠它注册）
            ScriptManagerBridge.LookupScriptsInAssembly(Assembly.GetExecutingAssembly());

            Log.Info($"[{ModId}] 守烬人已加载（PatchAll + 脚本扫描完成）。");
            Log.Info($"[{ModId}] 若选人界面看不到守烬人，请在控制台执行 dump，"
                   + "并把含 EMBERKEEPER 的行发出来。");
        }
        catch (Exception ex)
        {
            // 初始化失败不该拖垮整个游戏，但一定要把原因写进日志
            Log.Error($"[{ModId}] 初始化失败: {ex}");
        }
    }
}
