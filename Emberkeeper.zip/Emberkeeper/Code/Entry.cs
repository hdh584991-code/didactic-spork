using System.Reflection;
using Godot.Bridge;              // ScriptManagerBridge 在这里，不是 MegaCrit.Sts2.Core.Scripting
using HarmonyLib;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Modding;

namespace Emberkeeper.Code;

/// <summary>
/// 守烬人 mod 入口。
/// </summary>
[ModInitializer(nameof(Initialize))]
public static class Entry
{
    /// <summary>必须和 Emberkeeper.json 里的 id、以及资源文件夹名完全一致。</summary>
    public const string ModId = "Emberkeeper";

    private static Harmony? _harmony;

    public static void Initialize()
    {
        _harmony = new Harmony("sts2.emberkeeper");
        _harmony.PatchAll();

        // 让 Godot 扫描本程序集里的 C# 脚本（卡牌 / 遗物 / 能力 / 角色都靠它注册）
        var assembly = Assembly.GetExecutingAssembly();
        ScriptManagerBridge.LookupScriptsInAssembly(assembly);

        Log.Info($"[{ModId}] 守烬人已加载。");
    }
}
