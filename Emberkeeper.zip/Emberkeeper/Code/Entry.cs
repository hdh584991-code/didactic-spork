using HarmonyLib;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Modding;
// 如果 ScriptManagerBridge 不在这个命名空间，用 IDE 的自动导入修正即可（全局搜 ScriptManagerBridge）
using MegaCrit.Sts2.Core.Scripting;

namespace Emberkeeper.Code;

/// <summary>
/// 守烬人 mod 入口。
/// </summary>
[ModInitializer(nameof(Initialize))]
public static class Entry
{
    /// <summary>必须和 Emberkeeper.json 里的 id、以及资源文件夹名完全一致。</summary>
    public const string ModId = "Emberkeeper";

    private static Harmony? _harmony;

    public static void Initialize()
    {
        _harmony = new Harmony("sts2.emberkeeper");
        _harmony.PatchAll();

        // 让游戏扫描本程序集里的 C# 脚本（卡牌 / 遗物 / 能力 / 角色都靠它注册）
        ScriptManagerBridge.LookupScriptsInAssembly(typeof(Entry).Assembly);

        Log.Info($"[{ModId}] 守烬人已加载。");
    }
}
